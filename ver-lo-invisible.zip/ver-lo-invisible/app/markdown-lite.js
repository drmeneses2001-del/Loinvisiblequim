// markdown-lite.js
// Renderizador mínimo, propio, para el subconjunto de Markdown usado en los
// capítulos de esta app: párrafos, **negrita**, *cursiva*, `código`, listas
// con "- " y "1. ", tablas GFM (con pipes), y líneas que empiezan con los
// emojis de marcador de honestidad (🟦🟨🟪), que se destacan automáticamente.

function inline(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/\*([^*]+)\*/g, '<em>$1</em>')
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
}

function isTableRow(line) {
  return /^\s*\|.*\|\s*$/.test(line) || (line.includes('|') && line.trim().length > 0);
}
function isTableSeparator(line) {
  return /^\s*\|?\s*:?-+:?\s*(\|\s*:?-+:?\s*)+\|?\s*$/.test(line);
}

function renderTable(lines) {
  const rows = lines.map((l) =>
    l.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((c) => c.trim())
  );
  const header = rows[0];
  const body = rows.slice(2); // salta la fila separadora
  let html = '<div class="data-table-wrap"><table><thead><tr>';
  header.forEach((h) => (html += `<th>${inline(h)}</th>`));
  html += '</tr></thead><tbody>';
  body.forEach((r) => {
    html += '<tr>';
    r.forEach((c) => (html += `<td>${inline(c)}</td>`));
    html += '</tr>';
  });
  html += '</tbody></table></div>';
  return html;
}

export function renderMarkdown(md) {
  const lines = md.split('\n');
  let html = '';
  let i = 0;
  let paraBuf = [];
  let listBuf = [];
  let listType = null;

  function flushPara() {
    if (paraBuf.length) {
      const text = paraBuf.join(' ').trim();
      if (text) {
        const emojiMatch = text.match(/^(🟦|🟨|🟪)\s*(.*)$/);
        if (emojiMatch) {
          const cls = { '🟦': 'convencion', '🟨': 'simplificacion', '🟪': 'supuesto' }[emojiMatch[1]];
          const label = { convencion: 'Convención', simplificacion: 'Simplificación deliberada', supuesto: 'Supuesto / modelo' }[cls];
          // Quita el asterisco envolvente de cursiva y el prefijo redundante
          // ("Convención: ", "Simplificación deliberada: ", "Supuesto/modelo: ")
          // ya que la etiqueta coloreada del badge lo dice explícitamente.
          let rest = emojiMatch[2].trim().replace(/^\*([\s\S]*)\*$/, '$1');
          rest = rest.replace(/^(Convención|Simplificación deliberada|Supuesto\/modelo|Supuesto)\s*:\s*/i, '');
          html += `<div class="badge badge--${cls}"><span class="badge__label">${label}</span>${inline(rest)}</div>`;
        } else {
          html += `<p>${inline(text)}</p>`;
        }
      }
      paraBuf = [];
    }
  }
  function flushList() {
    if (listBuf.length) {
      const tag = listType === 'ol' ? 'ol' : 'ul';
      html += `<${tag}>` + listBuf.map((it) => `<li>${inline(it)}</li>`).join('') + `</${tag}>`;
      listBuf = [];
      listType = null;
    }
  }

  while (i < lines.length) {
    const line = lines[i];

    // Tabla GFM: línea con pipes seguida de línea separadora
    if (isTableRow(line) && lines[i + 1] && isTableSeparator(lines[i + 1])) {
      flushPara();
      flushList();
      const tableLines = [line, lines[i + 1]];
      let j = i + 2;
      while (j < lines.length && isTableRow(lines[j])) {
        tableLines.push(lines[j]);
        j++;
      }
      html += renderTable(tableLines);
      i = j;
      continue;
    }

    const ulMatch = line.match(/^\s*-\s+(.*)$/);
    const olMatch = line.match(/^\s*\d+\.\s+(.*)$/);
    if (ulMatch) {
      flushPara();
      if (listType && listType !== 'ul') flushList();
      listType = 'ul';
      listBuf.push(ulMatch[1]);
      i++;
      continue;
    }
    if (olMatch) {
      flushPara();
      if (listType && listType !== 'ol') flushList();
      listType = 'ol';
      listBuf.push(olMatch[1]);
      i++;
      continue;
    }

    if (line.trim() === '') {
      flushPara();
      flushList();
      i++;
      continue;
    }

    flushList();
    paraBuf.push(line.trim());
    i++;
  }
  flushPara();
  flushList();
  return html;
}
