// atom-model-compare.js — Unidad 1
import { mount as mountOrbitalCloud } from './orbital-cloud.js';

function daltonSVG() {
  return `<svg viewBox="0 0 220 200" width="100%" height="220">
    <circle cx="110" cy="100" r="55" fill="#F2B33D" opacity="0.85"/>
  </svg>`;
}
function thomsonSVG() {
  let dots = '';
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2;
    const r = 25 + (i % 3) * 8;
    dots += `<circle cx="${110 + r * Math.cos(a)}" cy="${100 + r * Math.sin(a)}" r="4" fill="#0B1220"/>`;
  }
  return `<svg viewBox="0 0 220 200" width="100%" height="220">
    <circle cx="110" cy="100" r="55" fill="#F2B33D" opacity="0.5"/>${dots}
  </svg>`;
}
function rutherfordSVG() {
  return `<svg viewBox="0 0 220 200" width="100%" height="220">
    <circle cx="110" cy="100" r="6" fill="#F2B33D"/>
    <circle cx="150" cy="70" r="4" fill="#A78BFA"/>
    <circle cx="60" cy="130" r="4" fill="#A78BFA"/>
    <circle cx="170" cy="120" r="4" fill="#A78BFA"/>
    <text x="110" y="185" text-anchor="middle" font-size="10" fill="#93A0B8">núcleo pequeño y denso; electrones dispersos</text>
  </svg>`;
}
function bohrSVG() {
  return `<svg viewBox="0 0 220 200" width="100%" height="220">
    <circle cx="110" cy="100" r="6" fill="#F2B33D"/>
    <circle cx="110" cy="100" r="35" fill="none" stroke="#93A0B8" stroke-width="1"/>
    <circle cx="110" cy="100" r="55" fill="none" stroke="#93A0B8" stroke-width="1"/>
    <circle cx="145" cy="100" r="4" fill="#A78BFA"/>
    <circle cx="55" cy="100" r="4" fill="#A78BFA"/>
  </svg>`;
}

const MODELS = [
  { id: 'dalton', label: 'Dalton (1803)', render: daltonSVG },
  { id: 'thomson', label: 'Thomson (1904)', render: thomsonSVG },
  { id: 'rutherford', label: 'Rutherford (1911)', render: rutherfordSVG },
  { id: 'bohr', label: 'Bohr (1913)', render: bohrSVG },
  { id: 'orbital', label: 'Nube orbital (real)', render: null },
];

export function mount(container, params) {
  const { modo, atomos } = params;
  container.innerHTML = '';

  const controls = document.createElement('div');
  controls.className = 'mol-viewer__controls';
  container.appendChild(controls);

  const stage = document.createElement('div');
  container.appendChild(stage);

  function activate(model) {
    [...controls.children].forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.id === model.id)));
    if (model.id === 'orbital') {
      mountOrbitalCloud(stage, { orbital: '1s' });
    } else {
      stage.innerHTML = model.render();
    }
  }

  MODELS.forEach((m) => {
    const btn = document.createElement('button');
    btn.textContent = m.label;
    btn.dataset.id = m.id;
    btn.addEventListener('click', () => activate(m));
    controls.appendChild(btn);
  });

  if (modo === 'comparacion-lado-a-lado' && atomos) {
    const note = document.createElement('p');
    note.className = 'dim';
    note.style.fontSize = '0.82rem';
    note.textContent = `Los mismos cinco modelos aplican conceptualmente a cualquier átomo (aquí: ${atomos.join(', ')}); lo que cambia es el número de electrones/capas, no la idea de cada modelo.`;
    container.appendChild(note);
  }

  activate(MODELS[0]);
}
