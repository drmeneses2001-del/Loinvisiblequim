// bibliography-table.js — Unidad 7
const ESTADO_LABEL = { verificado: '✅ Verificado', parcial: '⚠️ Parcial', pendiente: '🔎 Pendiente' };

export async function mount(container, params) {
  container.innerHTML = '';
  const res = await fetch(params.fuente || 'content/data/bibliography.json');
  const data = await res.json();
  const all = [
    ...data.primarias.map((r) => ({ ...r, grupo: 'Primaria (educación química / historia)' })),
    ...data.generales.map((r) => ({ ...r, grupo: 'General (química de referencia)' })),
  ];

  const filterBar = document.createElement('div');
  filterBar.className = 'filter-bar';
  container.appendChild(filterBar);

  const grupoSel = document.createElement('select');
  grupoSel.innerHTML = '<option value="">Todas las fuentes</option>' +
    [...new Set(all.map((r) => r.grupo))].map((g) => `<option value="${g}">${g}</option>`).join('');
  const estadoSel = document.createElement('select');
  estadoSel.innerHTML = '<option value="">Todos los estados</option>' +
    Object.entries(ESTADO_LABEL).map(([k, v]) => `<option value="${k}">${v}</option>`).join('');
  filterBar.appendChild(grupoSel);
  filterBar.appendChild(estadoSel);

  const summary = document.createElement('p');
  summary.className = 'dim';
  summary.style.fontSize = '0.82rem';
  container.appendChild(summary);

  const listHost = document.createElement('div');
  container.appendChild(listHost);

  function render() {
    const filtered = all.filter((r) =>
      (!grupoSel.value || r.grupo === grupoSel.value) &&
      (!estadoSel.value || r.estado === estadoSel.value)
    );
    const nVer = all.filter((r) => r.estado === 'verificado').length;
    const nPar = all.filter((r) => r.estado === 'parcial').length;
    const nPend = all.filter((r) => r.estado === 'pendiente').length;
    summary.textContent = `Total: ${all.length} referencias · ✅ ${nVer} verificadas · ⚠️ ${nPar} parciales · 🔎 ${nPend} pendientes.`;

    listHost.innerHTML = filtered.map((r) => `
      <div style="border-bottom:1px solid var(--border-soft);padding:0.7rem 0;">
        <div style="display:flex;justify-content:space-between;gap:0.6rem;flex-wrap:wrap;">
          <strong style="font-size:0.9rem;">${r.id}</strong>
          <span class="pill pill--${r.estado}">${ESTADO_LABEL[r.estado] || r.estado}</span>
        </div>
        <p style="margin:0.3rem 0;font-size:0.9rem;">${r.cita}</p>
        <p class="dim" style="margin:0;font-size:0.8rem;"><em>Uso en la app:</em> ${r.uso}</p>
        ${r.nota ? `<p class="dim" style="margin:0.2rem 0 0;font-size:0.78rem;">${r.nota}</p>` : ''}
      </div>
    `).join('') || '<p class="dim">Ninguna referencia coincide con estos filtros.</p>';
  }

  [grupoSel, estadoSel].forEach((s) => s.addEventListener('change', render));
  render();
}
