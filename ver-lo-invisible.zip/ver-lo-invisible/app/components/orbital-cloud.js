// orbital-cloud.js — Unidad 1: nube de probabilidad del átomo de hidrógeno
// Los puntos se generan por muestreo de rechazo sobre |psi|^2 de funciones de onda
// hidrogenoides reales (1s, 2p_z, 3d_z2), no son una imagen precalculada.
import * as THREE from '../../vendor/three.module.js';

const A0 = 1; // radio de Bohr normalizado a 1 (unidades arbitrarias de escena)

function psi1s(r) {
  return Math.exp(-r / A0);
}
function psi2pz(r, theta) {
  return r * Math.exp(-r / (2 * A0)) * Math.cos(theta);
}
function psi3dz2(r, theta) {
  const rho = r / (3 * A0);
  return (3 * Math.cos(theta) ** 2 - 1) * rho ** 2 * Math.exp(-rho);
}

const ORBITALS = {
  '1s': { fn: (r, th) => psi1s(r) ** 2, rmax: 6, label: '1s (esférico)' },
  '2pz': { fn: (r, th) => psi2pz(r, th) ** 2, rmax: 12, label: '2pz (dos lóbulos)' },
  '3dz2': { fn: (r, th) => psi3dz2(r, th) ** 2, rmax: 20, label: '3dz² (cuatro lóbulos + anillo)' },
};

function samplePoints(orbitalKey, n = 3500) {
  const { fn, rmax } = ORBITALS[orbitalKey];
  // Estimar el máximo de densidad por muestreo grueso, para normalizar el rechazo.
  let maxDensity = 0;
  for (let i = 0; i < 2000; i++) {
    const r = Math.random() * rmax;
    const theta = Math.random() * Math.PI;
    const d = fn(r, theta) * r * r; // jacobiano esférico ~ r^2 sin(theta), simplificado
    if (d > maxDensity) maxDensity = d;
  }
  const pts = [];
  let attempts = 0;
  while (pts.length < n && attempts < n * 400) {
    attempts++;
    const r = Math.random() * rmax;
    const theta = Math.acos(1 - 2 * Math.random());
    const phi = Math.random() * 2 * Math.PI;
    const density = fn(r, theta) * r * r * Math.sin(theta);
    if (Math.random() * maxDensity < density) {
      const x = r * Math.sin(theta) * Math.cos(phi);
      const y = r * Math.sin(theta) * Math.sin(phi);
      const z = r * Math.cos(theta);
      pts.push(x, y, z);
    }
  }
  return new Float32Array(pts);
}

export function mount(container, params) {
  const { orbital = '1s' } = params;
  container.innerHTML = '';
  const host = document.createElement('div');
  host.className = 'mol-viewer';
  container.appendChild(host);

  const controls = document.createElement('div');
  controls.className = 'mol-viewer__controls';
  Object.entries(ORBITALS).forEach(([key, o]) => {
    const btn = document.createElement('button');
    btn.textContent = o.label;
    btn.setAttribute('aria-pressed', String(key === orbital));
    btn.addEventListener('click', () => {
      [...controls.children].forEach((b) => b.setAttribute('aria-pressed', 'false'));
      btn.setAttribute('aria-pressed', 'true');
      buildCloud(key);
    });
    controls.appendChild(btn);
  });
  container.appendChild(controls);

  const note = document.createElement('p');
  note.className = 'dim';
  note.style.fontSize = '0.8rem';
  note.textContent = 'Cada punto es una posición donde el electrón podría encontrarse; la densidad de puntos representa la probabilidad, calculada a partir de la función de onda real, no dibujada a mano. Arrastra para rotar.';
  container.appendChild(note);

  const width = host.clientWidth || 320;
  const height = 320;
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
  camera.position.z = 18;
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setSize(width, height);
  host.appendChild(renderer.domElement);

  const group = new THREE.Group();
  scene.add(group);

  // Núcleo de referencia
  const nucleusGeom = new THREE.SphereGeometry(0.25, 16, 16);
  const nucleusMat = new THREE.MeshBasicMaterial({ color: 0xf2b33d });
  group.add(new THREE.Mesh(nucleusGeom, nucleusMat));

  let cloudPoints = null;
  function buildCloud(key) {
    if (cloudPoints) group.remove(cloudPoints);
    const positions = samplePoints(key);
    const geom = new THREE.BufferGeometry();
    geom.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const mat = new THREE.PointsMaterial({ color: 0xa78bfa, size: 0.12, transparent: true, opacity: 0.75 });
    cloudPoints = new THREE.Points(geom, mat);
    // Escalar para que quepa en la escena independientemente del rmax del orbital
    cloudPoints.scale.setScalar(6 / ORBITALS[key].rmax);
    group.add(cloudPoints);
  }
  buildCloud(orbital);

  // Rotación por arrastre (táctil y mouse), sin dependencias adicionales
  let dragging = false, lastX = 0, lastY = 0;
  function pointerDown(e) { dragging = true; const p = e.touches ? e.touches[0] : e; lastX = p.clientX; lastY = p.clientY; }
  function pointerMove(e) {
    if (!dragging) return;
    const p = e.touches ? e.touches[0] : e;
    const dx = p.clientX - lastX, dy = p.clientY - lastY;
    group.rotation.y += dx * 0.01;
    group.rotation.x += dy * 0.01;
    lastX = p.clientX; lastY = p.clientY;
    e.preventDefault();
  }
  function pointerUp() { dragging = false; }
  renderer.domElement.addEventListener('mousedown', pointerDown);
  renderer.domElement.addEventListener('mousemove', pointerMove);
  window.addEventListener('mouseup', pointerUp);
  renderer.domElement.addEventListener('touchstart', pointerDown, { passive: true });
  renderer.domElement.addEventListener('touchmove', pointerMove, { passive: false });
  renderer.domElement.addEventListener('touchend', pointerUp);

  let raf;
  function animate() {
    raf = requestAnimationFrame(animate);
    if (!dragging) group.rotation.y += 0.0025;
    renderer.render(scene, camera);
  }
  animate();

  // Limpieza si el nodo se desmonta del DOM (evita fugas al cambiar de capítulo)
  const observer = new MutationObserver(() => {
    if (!document.body.contains(host)) {
      cancelAnimationFrame(raf);
      observer.disconnect();
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
}
