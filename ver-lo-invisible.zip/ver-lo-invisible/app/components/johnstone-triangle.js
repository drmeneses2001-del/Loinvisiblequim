// johnstone-triangle.js — Unidad 0: el triángulo interactivo
// (el indicador "mini" persistente del header vive en johnstone-mini.js)

const CARDS = {
  agua: [
    { text: 'El agua hierve a 100 °C y produce vapor', nivel: 'macro' },
    { text: 'H₂O(l) → H₂O(g)', nivel: 'simbolico' },
    { text: 'Las moléculas rompen puentes de hidrógeno y se separan', nivel: 'submicro' },
  ],
};

const VERTS = {
  macro: { x: 110, y: 20, color: '#F2B33D', label: 'Macroscópico' },
  submicro: { x: 20, y: 175, color: '#A78BFA', label: 'Submicroscópico' },
  simbolico: { x: 200, y: 175, color: '#6EE7B7', label: 'Simbólico' },
};

export function mount(container, params) {
  const { ejemplo = 'agua' } = params;
  container.innerHTML = '';
  const wrap = document.createElement('div');
  wrap.className = 'johnstone-triangle';

  wrap.innerHTML = `
    <svg viewBox="0 0 220 200">
      <polygon points="${VERTS.macro.x},${VERTS.macro.y} ${VERTS.submicro.x},${VERTS.submicro.y} ${VERTS.simbolico.x},${VERTS.simbolico.y}"
        fill="none" stroke="#26324A" stroke-width="2"/>
      ${Object.values(VERTS).map(v => `<circle cx="${v.x}" cy="${v.y}" r="6" fill="${v.color}"/>`).join('')}
      ${Object.values(VERTS).map(v => `<text x="${v.x}" y="${v.y + (v.y < 100 ? -12 : 20)}" text-anchor="middle" font-size="10" fill="#93A0B8">${v.label}</text>`).join('')}
    </svg>
    <div class="cards" style="display:flex;flex-wrap:wrap;gap:0.5rem;justify-content:center;"></div>
    <p class="dim" style="font-size:0.8rem;text-align:center;margin-top:0.3rem;">Toca una tarjeta para ver a qué vértice pertenece y por qué.</p>
    <div class="answer" style="min-height:1.4em;font-size:0.88rem;text-align:center;"></div>
  `;

  const cardsHost = wrap.querySelector('.cards');
  const answer = wrap.querySelector('.answer');
  (CARDS[ejemplo] || CARDS.agua).forEach((c) => {
    const btn = document.createElement('button');
    btn.textContent = c.text;
    btn.style.cssText = 'background:var(--bg-panel-raised);border:1px solid var(--border-soft);color:var(--ink);padding:0.5rem 0.8rem;border-radius:8px;font-size:0.82rem;min-height:44px;';
    btn.addEventListener('click', () => {
      const v = VERTS[c.nivel];
      answer.innerHTML = `<span style="color:${v.color}">●</span> "${c.text}" pertenece al nivel <strong style="color:${v.color}">${v.label.toLowerCase()}</strong>.`;
    });
    cardsHost.appendChild(btn);
  });

  container.appendChild(wrap);
}
