// mol-viewer.js
// Envoltorio delgado sobre 3Dmol.js (vendor/3Dmol-min.js, cargado globalmente como $3Dmol).
// Un único componente reutilizado por: representation-panel (U2), ring-toggle (U4),
// protein-layers (U5) y cualquier "::: interactivo mol-viewer {...}" suelto.

const STYLE_LABELS = {
  stick: 'Bolas y varillas',
  sphere: 'Espacio-lleno',
  line: 'Esqueleto (líneas)',
  cartoon: 'Listones',
};

async function fetchText(path) {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`No se pudo cargar ${path}`);
  return res.text();
}

function distance(a, b) {
  return Math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2 + (a.z - b.z) ** 2);
}

/**
 * createMolViewer — API mínima definida en la arquitectura.
 * @param {HTMLElement} el
 * @param {Object} opts
 *   source: ruta al .sdf o .pdb
 *   format: 'sdf' | 'pdb'
 *   styles: lista de estilos disponibles para alternar, p.ej. ['stick','sphere']
 *   defaultStyle: estilo inicial
 *   measure: boolean, permite medir distancias tocando dos átomos
 *   colorScheme: 'cpk' | 'ss' (estructura secundaria, para proteínas)
 *   caption: texto opcional bajo el visor
 */
export async function createMolViewer(el, opts) {
  const {
    source,
    format = 'sdf',
    styles = ['stick', 'sphere'],
    defaultStyle = styles[0],
    measure = false,
    colorScheme = 'cpk',
    caption = '',
  } = opts;

  el.innerHTML = '';
  const viewerBox = document.createElement('div');
  viewerBox.className = 'mol-viewer';
  el.appendChild(viewerBox);

  if (typeof window.$3Dmol === 'undefined') {
    viewerBox.innerHTML = '<div class="webgl-fallback">No se pudo cargar el motor de visualización 3D (3Dmol.js).</div>';
    return null;
  }

  let raw;
  try {
    raw = await fetchText(source);
  } catch (e) {
    viewerBox.innerHTML = `<div class="webgl-fallback">No se pudo cargar la estructura (${source}). Si abriste index.html directamente con doble clic, sírvelo desde un servidor estático local (ver README).</div>`;
    return null;
  }

  let viewer;
  try {
    viewer = window.$3Dmol.createViewer(viewerBox, { backgroundColor: '#06090F' });
  } catch (e) {
    viewerBox.innerHTML = '<div class="webgl-fallback">Este dispositivo no soporta WebGL; no se puede mostrar el modelo 3D interactivo.</div>';
    return null;
  }

  const model = viewer.addModel(raw, format);
  let currentStyle = defaultStyle;

  function applyStyle(styleName) {
    const styleSpec = {};
    if (styleName === 'stick') styleSpec.stick = { radius: 0.15 };
    if (styleName === 'sphere') styleSpec.sphere = { scale: 0.9 };
    if (styleName === 'line') styleSpec.line = { linewidth: 2 };
    if (styleName === 'cartoon') styleSpec.cartoon = { color: 'spectrum' };
    if (colorScheme === 'ss' && styleName === 'cartoon') {
      styleSpec.cartoon = { color: 'spectrum' };
    }
    viewer.setStyle({}, styleSpec);
    viewer.zoomTo();
    viewer.render();
    currentStyle = styleName;
  }
  applyStyle(defaultStyle);

  // ---- Controles de estilo ----
  const controls = document.createElement('div');
  controls.className = 'mol-viewer__controls';
  styles.forEach((s) => {
    const btn = document.createElement('button');
    btn.textContent = STYLE_LABELS[s] || s;
    btn.setAttribute('aria-pressed', String(s === defaultStyle));
    btn.addEventListener('click', () => {
      applyStyle(s);
      [...controls.children].forEach((b) => b.setAttribute('aria-pressed', 'false'));
      btn.setAttribute('aria-pressed', 'true');
    });
    controls.appendChild(btn);
  });
  el.appendChild(controls);

  // ---- Medición de distancias (tocar dos átomos) ----
  let readout = null;
  if (measure) {
    readout = document.createElement('div');
    readout.className = 'mol-viewer__measure-readout';
    readout.textContent = 'Toca dos átomos para medir la distancia entre ellos.';
    el.appendChild(readout);

    let selected = [];
    let shapes = [];
    viewer.setClickable({}, true, (atom) => {
      selected.push(atom);
      shapes.push(viewer.addSphere({ center: atom, radius: 0.35, color: '#6EE7B7' }));
      if (selected.length === 2) {
        const d = distance(selected[0], selected[1]);
        readout.textContent = `Distancia ${selected[0].elem}–${selected[1].elem}: ${d.toFixed(3)} Å`;
        viewer.addLine({ start: selected[0], end: selected[1], color: '#6EE7B7' });
        viewer.render();
        setTimeout(() => {
          shapes.forEach((s) => viewer.removeShape(s));
          shapes = [];
          selected = [];
        }, 2500);
      }
      viewer.render();
    });
  }

  if (caption) {
    const cap = document.createElement('p');
    cap.className = 'dim';
    cap.style.fontSize = '0.8rem';
    cap.style.marginTop = '0.5rem';
    cap.textContent = caption;
    el.appendChild(cap);
  }

  return { viewer, model, applyStyle };
}

const MOLECULE_PATHS = {
  etanol: 'content/data/molecules/etanol.sdf',
  dimetileter: 'content/data/molecules/dimetileter.sdf',
  metano: 'content/data/molecules/metano.sdf',
  benceno: 'content/data/molecules/benceno.sdf',
  ciclohexano: 'content/data/molecules/ciclohexano.sdf',
  bromometano: 'content/data/molecules/bromometano.sdf',
  hidroxido: 'content/data/molecules/hidroxido.sdf',
  agua: 'content/data/molecules/agua.sdf',
};

const PROTEIN_PATHS = {
  'helice-alfa-sintetica': 'content/data/proteins/helice_alfa_sintetica.pdb',
  'lamina-beta-sintetica': 'content/data/proteins/lamina_beta_sintetica.pdb',
  'proteina-esquematica-sintetica': 'content/data/proteins/proteina_esquematica_sintetica.pdb',
};

export function resolveMoleculeSource(name) {
  return MOLECULE_PATHS[name] || null;
}
export function resolveProteinSource(name) {
  return PROTEIN_PATHS[name] || null;
}

/**
 * mount — punto de entrada usado por el router de componentes de main.js
 * para bloques "::: interactivo mol-viewer {...}".
 */
export async function mount(container, params) {
  const { molecula, comparar_con, estilos, medir, nota } = params;
  if (comparar_con) {
    container.classList.add('mol-viewer-pair');
    const figA = document.createElement('figure');
    const figB = document.createElement('figure');
    const capA = document.createElement('figcaption');
    const capB = document.createElement('figcaption');
    capA.textContent = molecula;
    capB.textContent = comparar_con;
    figA.appendChild(document.createElement('div'));
    figB.appendChild(document.createElement('div'));
    figA.appendChild(capA);
    figB.appendChild(capB);
    container.appendChild(figA);
    container.appendChild(figB);
    await createMolViewer(figA.firstChild, {
      source: resolveMoleculeSource(molecula),
      styles: estilos || ['stick', 'sphere'],
      measure: !!medir,
    });
    await createMolViewer(figB.firstChild, {
      source: resolveMoleculeSource(comparar_con),
      styles: estilos || ['stick', 'sphere'],
      measure: !!medir,
    });
    if (nota) {
      const p = document.createElement('p');
      p.className = 'dim';
      p.style.gridColumn = '1 / -1';
      p.style.fontSize = '0.8rem';
      p.textContent = nota;
      container.appendChild(p);
    }
  } else {
    await createMolViewer(container, {
      source: resolveMoleculeSource(molecula),
      styles: estilos || ['stick', 'sphere'],
      measure: !!medir,
    });
  }
}
