// johnstone-mini.js — indicador persistente de tres puntos en el encabezado
export const LETRA_A_NIVEL = {
  A: 'macro',
  B: 'simbolico',
  C: 'simbolico',
  D: 'submicro',
  E: 'submicro',
  F: 'simbolico',
  G: 'submicro',
  H: null,
};

export function createJohnstoneMini(hostEl) {
  hostEl.innerHTML = `
    <span class="johnstone-mini" title="Nivel de Johnstone del contenido visible">
      <span class="johnstone-mini__dot macro" data-nivel="macro"></span>
      <span class="johnstone-mini__dot submicro" data-nivel="submicro"></span>
      <span class="johnstone-mini__dot simbolico" data-nivel="simbolico"></span>
    </span>
  `;
  return {
    setLevel(nivel) {
      hostEl.querySelectorAll('.johnstone-mini__dot').forEach((d) => {
        d.classList.toggle('is-active', d.dataset.nivel === nivel);
      });
    },
  };
}
