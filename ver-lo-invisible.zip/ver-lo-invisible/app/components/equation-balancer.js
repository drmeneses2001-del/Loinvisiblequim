// equation-balancer.js — Unidad 3: balancear CH4 + O2 -> CO2 + H2O contando átomos
const REACTIONS = {
  'combustion-metano': {
    reactivos: [
      { formula: 'CH₄', atomos: { C: 1, H: 4 }, coefFijo: 1 },
      { formula: 'O₂', atomos: { O: 2 }, coefInicial: 1 },
    ],
    productos: [
      { formula: 'CO₂', atomos: { C: 1, O: 2 }, coefInicial: 1 },
      { formula: 'H₂O', atomos: { H: 2, O: 1 }, coefInicial: 1 },
    ],
    objetivo: { reactivos: [1, 2], productos: [1, 2] },
  },
};

function tally(species, coefs) {
  const totals = {};
  species.forEach((sp, i) => {
    const c = coefs[i];
    Object.entries(sp.atomos).forEach(([el, n]) => {
      totals[el] = (totals[el] || 0) + c * n;
    });
  });
  return totals;
}

export function mount(container, params) {
  const { reaccion = 'combustion-metano' } = params;
  const R = REACTIONS[reaccion];
  container.innerHTML = '';

  const coefsReact = R.reactivos.map((sp) => sp.coefFijo || sp.coefInicial || 1);
  const coefsProd = R.productos.map((sp) => sp.coefInicial || 1);

  const eqLine = document.createElement('div');
  eqLine.style.cssText = 'font-family:var(--font-mono);font-size:1.05rem;text-align:center;margin-bottom:1rem;';
  container.appendChild(eqLine);

  const columns = document.createElement('div');
  columns.style.cssText = 'display:flex;gap:1.2rem;flex-wrap:wrap;justify-content:center;';
  container.appendChild(columns);

  function speciesControl(sp, idx, coefs, fixed) {
    const box = document.createElement('div');
    box.style.cssText = 'background:var(--bg-panel-raised);border:1px solid var(--border-soft);border-radius:8px;padding:0.6rem 0.9rem;text-align:center;min-width:100px;';
    box.innerHTML = `<div class="formula" style="font-size:1.1rem;margin-bottom:0.4rem;">${sp.formula}</div>`;
    if (fixed) {
      box.innerHTML += `<div class="dim" style="font-size:0.75rem;">coeficiente fijo: ${coefs[idx]}</div>`;
    } else {
      const row = document.createElement('div');
      row.style.cssText = 'display:flex;align-items:center;gap:0.4rem;justify-content:center;';
      const minus = document.createElement('button');
      minus.textContent = '−';
      minus.style.cssText = 'min-width:36px;min-height:36px;border-radius:6px;border:1px solid var(--border-soft);background:var(--bg-panel);color:var(--ink);';
      const val = document.createElement('span');
      val.style.cssText = 'font-family:var(--font-mono);min-width:1.5em;text-align:center;';
      const plus = document.createElement('button');
      plus.textContent = '+';
      plus.style.cssText = minus.style.cssText;
      function refresh() { val.textContent = coefs[idx]; }
      minus.addEventListener('click', () => { coefs[idx] = Math.max(1, coefs[idx] - 1); refresh(); update(); });
      plus.addEventListener('click', () => { coefs[idx] = Math.min(6, coefs[idx] + 1); refresh(); update(); });
      row.appendChild(minus); row.appendChild(val); row.appendChild(plus);
      refresh();
      box.appendChild(row);
    }
    return box;
  }

  const colReact = document.createElement('div');
  colReact.style.cssText = 'display:flex;gap:0.6rem;';
  const colProd = document.createElement('div');
  colProd.style.cssText = 'display:flex;gap:0.6rem;';

  const status = document.createElement('div');
  status.style.cssText = 'text-align:center;margin-top:1rem;font-size:0.9rem;';

  const tallyBox = document.createElement('div');
  tallyBox.className = 'data-table-wrap';

  function update() {
    const eqText = R.reactivos.map((sp, i) => (coefsReact[i] > 1 ? coefsReact[i] : '') + sp.formula).join(' + ')
      + '  →  ' + R.productos.map((sp, i) => (coefsProd[i] > 1 ? coefsProd[i] : '') + sp.formula).join(' + ');
    eqLine.textContent = eqText;

    const tR = tally(R.reactivos, coefsReact);
    const tP = tally(R.productos, coefsProd);
    const elems = [...new Set([...Object.keys(tR), ...Object.keys(tP)])].sort();
    let html = '<table><thead><tr><th>Elemento</th><th>Átomos a la izquierda</th><th>Átomos a la derecha</th><th></th></tr></thead><tbody>';
    let balanced = true;
    elems.forEach((el) => {
      const l = tR[el] || 0, r = tP[el] || 0;
      const ok = l === r;
      if (!ok) balanced = false;
      html += `<tr><td>${el}</td><td>${l}</td><td>${r}</td><td>${ok ? '✅' : '❌'}</td></tr>`;
    });
    html += '</tbody></table>';
    tallyBox.innerHTML = html;
    status.textContent = balanced ? '✅ Ecuación balanceada — el número de átomos de cada elemento coincide a ambos lados.' : 'Todavía no está balanceada: ajusta los coeficientes con los botones + / −.';
    status.style.color = balanced ? 'var(--nivel-simbolico)' : 'var(--ink-dim)';
  }

  R.reactivos.forEach((sp, i) => colReact.appendChild(speciesControl(sp, i, coefsReact, !!sp.coefFijo)));
  R.productos.forEach((sp, i) => colProd.appendChild(speciesControl(sp, i, coefsProd, false)));
  columns.appendChild(colReact);
  const arrow = document.createElement('div');
  arrow.style.cssText = 'display:flex;align-items:center;font-size:1.4rem;color:var(--ink-faint);';
  arrow.textContent = '→';
  columns.appendChild(arrow);
  columns.appendChild(colProd);

  container.appendChild(status);
  container.appendChild(tallyBox);
  update();
}
