// comparison-table.js — Unidad 6
const NIVEL_LABEL = { macro: 'Macroscópico', submicroscopico: 'Submicroscópico', simbolico: 'Simbólico' };
const MARCADOR_LABEL = { convencion: 'Convención', simplificacion: 'Simplificación', supuesto: 'Supuesto' };

export async function mount(container, params) {
  container.innerHTML = '';
  const res = await fetch(params.fuente || 'content/data/comparison-table.json');
  const rows = await res.json();

  const filterBar = document.createElement('div');
  filterBar.className = 'filter-bar';
  container.appendChild(filterBar);

  const unidadSel = document.createElement('select');
  unidadSel.innerHTML = '<option value="">Todas las unidades</option>' +
    [...new Set(rows.map((r) => r.unidad))].sort().map((u) => `<option value="${u}">Unidad ${u}</option>`).join('');
  const nivelSel = document.createElement('select');
  nivelSel.innerHTML = '<option value="">Todos los niveles</option>' +
    Object.entries(NIVEL_LABEL).map(([k, v]) => `<option value="${k}">${v}</option>`).join('');
  const marcadorSel = document.createElement('select');
  marcadorSel.innerHTML = '<option value="">Todos los marcadores</option>' +
    Object.entries(MARCADOR_LABEL).map(([k, v]) => `<option value="${k}">${v}</option>`).join('');
  filterBar.appendChild(unidadSel);
  filterBar.appendChild(nivelSel);
  filterBar.appendChild(marcadorSel);

  const tableWrap = document.createElement('div');
  tableWrap.className = 'data-table-wrap';
  container.appendChild(tableWrap);

  function render() {
    const filtered = rows.filter((r) =>
      (!unidadSel.value || String(r.unidad) === unidadSel.value) &&
      (!nivelSel.value || r.nivel === nivelSel.value) &&
      (!marcadorSel.value || r.marcador === marcadorSel.value)
    );
    let html = '<table><thead><tr><th>Unidad</th><th>Representación</th><th>Qué muestra</th><th>Qué oculta</th><th>Nivel</th><th>Error típico</th><th>Marcador</th></tr></thead><tbody>';
    filtered.forEach((r) => {
      html += `<tr>
        <td>${r.unidad}</td>
        <td>${r.representacion}</td>
        <td>${r.muestra}</td>
        <td>${r.oculta}</td>
        <td>${NIVEL_LABEL[r.nivel] || r.nivel}</td>
        <td>${r.error_tipico}</td>
        <td><span class="pill pill--${r.marcador}">${MARCADOR_LABEL[r.marcador] || r.marcador}</span></td>
      </tr>`;
    });
    html += '</tbody></table>';
    tableWrap.innerHTML = html;
    if (!filtered.length) tableWrap.innerHTML = '<p class="dim">Ninguna fila coincide con estos filtros.</p>';
  }

  [unidadSel, nivelSel, marcadorSel].forEach((s) => s.addEventListener('change', render));
  render();
}
