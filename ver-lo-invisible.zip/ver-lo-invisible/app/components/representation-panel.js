// representation-panel.js — Unidad 2: "una molécula, cinco lenguajes"
import { createMolViewer, resolveMoleculeSource } from './mol-viewer.js';

const LANGS = {
  etanol: {
    molecular: 'C₂H₆O',
    estructural: 'CH₃—CH₂—O—H (todos los enlaces)',
    condensada: 'CH₃CH₂OH',
    esqueleto: '/ \\ OH  (vértice = carbono, H en C omitidos)',
  },
  dimetileter: {
    molecular: 'C₂H₆O',
    estructural: 'CH₃—O—CH₃ (todos los enlaces)',
    condensada: 'CH₃OCH₃',
    esqueleto: '\\ O /  (vértice = carbono, H en C omitidos)',
  },
};

export async function mount(container, params) {
  const { molecula = 'etanol', contraste } = params;
  container.innerHTML = '';

  const grid = document.createElement('div');
  grid.className = 'representation-panel';
  container.appendChild(grid);

  const moleculeSelect = document.createElement('div');
  if (contraste) {
    moleculeSelect.className = 'mol-viewer__controls';
    [molecula, contraste].forEach((name, idx) => {
      const btn = document.createElement('button');
      btn.textContent = name === 'etanol' ? 'Etanol (C₂H₆O)' : 'Dimetil éter (C₂H₆O)';
      btn.setAttribute('aria-pressed', String(idx === 0));
      btn.addEventListener('click', () => {
        [...moleculeSelect.children].forEach((b) => b.setAttribute('aria-pressed', 'false'));
        btn.setAttribute('aria-pressed', 'true');
        renderLangs(name);
        viewerHandle && viewerHandle.viewer && loadViewer(name);
      });
      moleculeSelect.appendChild(btn);
    });
    container.appendChild(moleculeSelect);
  }

  const viewerHost = document.createElement('div');
  container.appendChild(viewerHost);
  let viewerHandle = null;

  function renderLangs(name) {
    grid.innerHTML = '';
    const langs = LANGS[name];
    const order = [
      ['molecular', 'Fórmula molecular'],
      ['estructural', 'Fórmula estructural'],
      ['condensada', 'Fórmula condensada'],
      ['esqueleto', 'Esqueleto (línea-ángulo)'],
    ];
    order.forEach(([key, label]) => {
      const card = document.createElement('div');
      card.className = 'representation-card';
      card.innerHTML = `<div class="representation-card__label">${label}</div><div class="representation-card__value">${langs[key]}</div>`;
      grid.appendChild(card);
    });
    const card3d = document.createElement('div');
    card3d.className = 'representation-card';
    card3d.innerHTML = `<div class="representation-card__label">Modelo 3D</div><div class="representation-card__value">ver abajo ↓</div>`;
    grid.appendChild(card3d);
  }

  async function loadViewer(name) {
    viewerHost.innerHTML = '';
    viewerHandle = await createMolViewer(viewerHost, {
      source: resolveMoleculeSource(name),
      styles: ['stick', 'sphere'],
      measure: true,
      caption: 'Toca "Bolas y varillas" o "Espacio-lleno" para alternar; toca dos átomos para medir la distancia entre ellos.',
    });
  }

  renderLangs(molecula);
  await loadViewer(molecula);
}
