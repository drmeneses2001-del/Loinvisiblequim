// ring-toggle.js — Unidad 4: Kekulé A ↔ Kekulé B ↔ círculo ↔ 3D (benceno)
import { createMolViewer, resolveMoleculeSource } from './mol-viewer.js';

// Hexágono regular centrado en (110,100), radio 70
const R = 70, CX = 110, CY = 100;
function vertex(i) {
  const angle = (Math.PI / 180) * (60 * i - 90);
  return [CX + R * Math.cos(angle), CY + R * Math.sin(angle)];
}
const V = [0, 1, 2, 3, 4, 5].map(vertex);

function hexagonOutline() {
  return V.map((p) => p.join(',')).join(' ');
}

function kekuleSVG(startDouble) {
  // startDouble: true -> enlaces dobles en (0-1),(2-3),(4-5); false -> en (1-2),(3-4),(5-0)
  let bonds = '';
  for (let i = 0; i < 6; i++) {
    const [x1, y1] = V[i];
    const [x2, y2] = V[(i + 1) % 6];
    const isDouble = startDouble ? i % 2 === 0 : i % 2 === 1;
    bonds += `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="var(--nivel-simbolico)" stroke-width="3"/>`;
    if (isDouble) {
      const dx = (x2 - x1), dy = (y2 - y1);
      const len = Math.sqrt(dx * dx + dy * dy);
      const nx = -dy / len * 6, ny = dx / len * 6;
      const midInsetX1 = x1 + dx * 0.18, midInsetY1 = y1 + dy * 0.18;
      const midInsetX2 = x1 + dx * 0.82, midInsetY2 = y1 + dy * 0.82;
      bonds += `<line x1="${midInsetX1 + nx * -1.6}" y1="${midInsetY1 + ny * -1.6}" x2="${midInsetX2 + nx * -1.6}" y2="${midInsetY2 + ny * -1.6}" stroke="var(--nivel-simbolico)" stroke-width="3"/>`;
    }
  }
  return `<svg viewBox="0 0 220 200" width="100%" height="220">${bonds}
    ${V.map(([x, y]) => `<circle cx="${x}" cy="${y}" r="3" fill="var(--ink-dim)"/>`).join('')}
  </svg>`;
}

function circleSVG() {
  let bonds = '';
  for (let i = 0; i < 6; i++) {
    const [x1, y1] = V[i];
    const [x2, y2] = V[(i + 1) % 6];
    bonds += `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="var(--nivel-simbolico)" stroke-width="3"/>`;
  }
  return `<svg viewBox="0 0 220 200" width="100%" height="220">${bonds}
    <circle cx="${CX}" cy="${CY}" r="${R * 0.62}" fill="none" stroke="var(--nivel-submicro)" stroke-width="3"/>
    ${V.map(([x, y]) => `<circle cx="${x}" cy="${y}" r="3" fill="var(--ink-dim)"/>`).join('')}
  </svg>`;
}

export async function mount(container, params) {
  const { molecula = 'benceno' } = params;
  container.innerHTML = '';

  const stage = document.createElement('div');
  stage.style.display = 'flex';
  stage.style.justifyContent = 'center';
  container.appendChild(stage);

  const noteEl = document.createElement('p');
  noteEl.className = 'dim';
  noteEl.style.fontSize = '0.82rem';
  noteEl.style.textAlign = 'center';
  container.appendChild(noteEl);

  const modes = [
    { id: 'kekuleA', label: 'Kekulé A', render: () => (stage.innerHTML = kekuleSVG(true)), note: 'Un patrón posible de enlaces alternados — un "testigo" de la molécula.' },
    { id: 'kekuleB', label: 'Kekulé B', render: () => (stage.innerHTML = kekuleSVG(false)), note: 'El otro patrón posible, igual de válido y de incompleto que el A.' },
    { id: 'circulo', label: 'Círculo (deslocalización)', render: () => (stage.innerHTML = circleSVG()), note: 'Los 6 electrones π repartidos por igual entre los 6 carbonos.' },
    { id: '3d', label: 'Modelo 3D', render: null, note: 'Las seis distancias C–C son idénticas: ni simples ni dobles, un valor intermedio.' },
  ];

  const controls = document.createElement('div');
  controls.className = 'mol-viewer__controls';
  container.insertBefore(controls, stage);

  let viewerMounted = false;
  async function activate(mode) {
    [...controls.children].forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.id === mode.id)));
    noteEl.textContent = mode.note;
    if (mode.id === '3d') {
      stage.innerHTML = '';
      const host = document.createElement('div');
      host.style.width = '100%';
      stage.appendChild(host);
      await createMolViewer(host, {
        source: resolveMoleculeSource(molecula),
        styles: ['stick', 'sphere'],
        measure: true,
        caption: 'Toca dos carbonos adyacentes para medir su distancia; repite en distintos pares y compáralas.',
      });
    } else {
      mode.render();
    }
  }

  modes.forEach((m) => {
    const btn = document.createElement('button');
    btn.textContent = m.label;
    btn.dataset.id = m.id;
    btn.addEventListener('click', () => activate(m));
    controls.appendChild(btn);
  });

  await activate(modes[0]);
}
