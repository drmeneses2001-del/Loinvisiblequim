// curved-arrows.js — Unidad 3: animación de flechas curvas para una transferencia
// de protón ácido-base genérica: H—A + :B  →  A:¯ + H—B⁺
export function mount(container, params) {
  container.innerHTML = '';
  const wrap = document.createElement('div');
  wrap.innerHTML = `
    <svg viewBox="0 0 420 160" width="100%" height="180">
      <defs>
        <marker id="arrowhead" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
          <path d="M0,0 L6,3 L0,6 Z" fill="#6EE7B7"/>
        </marker>
      </defs>
      <!-- H-A -->
      <text x="60" y="80" font-size="20" fill="#E8EDF5" text-anchor="middle">H—A</text>
      <!-- :B -->
      <text x="220" y="80" font-size="20" fill="#E8EDF5" text-anchor="middle">:B</text>
      <text x="360" y="80" font-size="16" fill="#93A0B8" text-anchor="middle">A⁻ ··· H—B⁺</text>

      <path id="arrow1" d="M 210 65 C 180 20, 100 20, 68 65" fill="none" stroke="#6EE7B7" stroke-width="2.5"
            marker-end="url(#arrowhead)" stroke-dasharray="140" stroke-dashoffset="140"/>
      <path id="arrow2" d="M 60 90 C 60 130, 150 130, 200 90" fill="none" stroke="#F2B33D" stroke-width="2.5"
            marker-end="url(#arrowhead)" stroke-dasharray="150" stroke-dashoffset="150"/>
    </svg>
    <div style="display:flex;gap:0.6rem;justify-content:center;">
      <button id="playBtn" style="background:var(--bg-panel-raised);border:1px solid var(--border-soft);color:var(--ink);padding:0.5rem 1rem;border-radius:999px;min-height:44px;">▶ Reproducir mecanismo</button>
    </div>
    <p class="dim" style="font-size:0.82rem;text-align:center;margin-top:0.5rem;">
      Flecha verde: el par de electrones no compartido de B se mueve para formar un nuevo enlace con H.
      Flecha ámbar: el par de electrones del enlace H–A se queda en A, que se convierte en A⁻.
    </p>
  `;
  container.appendChild(wrap);

  const a1 = wrap.querySelector('#arrow1');
  const a2 = wrap.querySelector('#arrow2');
  const btn = wrap.querySelector('#playBtn');

  function reset() {
    a1.style.transition = 'none';
    a2.style.transition = 'none';
    a1.style.strokeDashoffset = '140';
    a2.style.strokeDashoffset = '150';
  }
  function play() {
    reset();
    requestAnimationFrame(() => {
      a1.style.transition = 'stroke-dashoffset 900ms ease';
      a1.style.strokeDashoffset = '0';
      setTimeout(() => {
        a2.style.transition = 'stroke-dashoffset 900ms ease';
        a2.style.strokeDashoffset = '0';
      }, 900);
    });
  }
  btn.addEventListener('click', play);
  reset();
}
