// protein-layers.js — Unidad 5: capas de representación de una proteína
import { resolveProteinSource } from './mol-viewer.js';

const LAYER_INFO = {
  atomos: {
    label: 'Todos los átomos',
    styleSpec: { stick: { radius: 0.15 } },
    sel: {},
    note: 'A esta escala, el modelo de todos los átomos ya empieza a resultar difícil de leer — y esta es una proteína pequeña.',
  },
  esqueleto: {
    label: 'Esqueleto (solo Cα)',
    styleSpec: { line: { linewidth: 3 } },
    sel: { atom: 'CA' },
    note: 'Solo se conecta el carbono central de cada aminoácido: se pierde toda la información de las cadenas laterales.',
  },
  listones: {
    label: 'Listones (ribbon)',
    styleSpec: { cartoon: { color: 'spectrum' } },
    sel: {},
    note: 'Ningún átomo se dibuja de forma explícita: la forma se interpola matemáticamente entre los Cα.',
  },
  cuaternaria: {
    label: 'Subunidades (cuaternaria)',
    styleSpec: { cartoon: { colorscheme: 'chain' } },
    sel: {},
    note: 'Cada color es una subunidad (cadena) distinta de la estructura.',
  },
};

export async function mount(container, params) {
  const { estructura = 'proteina-esquematica-sintetica', capas = ['atomos', 'esqueleto', 'listones'], contador_atomos } = params;
  container.innerHTML = '';

  const warn = document.createElement('p');
  warn.className = 'dim';
  warn.style.fontSize = '0.78rem';
  warn.innerHTML = '⚠️ Estructura sintética generada con parámetros geométricos estándar (hélice α / lámina β), no una entrada real del PDB. Ver nota en el texto del capítulo.';
  container.appendChild(warn);

  const viewerBox = document.createElement('div');
  viewerBox.className = 'mol-viewer';
  container.appendChild(viewerBox);

  const controls = document.createElement('div');
  controls.className = 'mol-viewer__controls';
  container.appendChild(controls);

  const note = document.createElement('p');
  note.className = 'dim';
  note.style.fontSize = '0.85rem';
  container.appendChild(note);

  let atomCountEl = null;
  if (contador_atomos) {
    atomCountEl = document.createElement('div');
    atomCountEl.className = 'mol-viewer__measure-readout';
    container.appendChild(atomCountEl);
  }

  if (typeof window.$3Dmol === 'undefined') {
    viewerBox.innerHTML = '<div class="webgl-fallback">No se pudo cargar el motor 3D.</div>';
    return;
  }

  const source = resolveProteinSource(estructura);
  let raw;
  try {
    const res = await fetch(source);
    raw = await res.text();
  } catch (e) {
    viewerBox.innerHTML = '<div class="webgl-fallback">No se pudo cargar la estructura de proteína. Sirve la app desde un servidor estático local.</div>';
    return;
  }

  const viewer = window.$3Dmol.createViewer(viewerBox, { backgroundColor: '#06090F' });
  viewer.addModel(raw, 'pdb');
  const totalAtoms = (raw.match(/^ATOM/gm) || []).length;

  function applyLayer(id) {
    const info = LAYER_INFO[id];
    viewer.setStyle({}, {});
    viewer.setStyle(info.sel, info.styleSpec);
    viewer.zoomTo();
    viewer.render();
    note.textContent = info.note;
    if (atomCountEl) {
      const shown = id === 'esqueleto' ? Math.round(totalAtoms / 4) : id === 'atomos' ? totalAtoms : 0;
      atomCountEl.textContent = `Átomos en el archivo: ${totalAtoms} · Átomos dibujados explícitamente en esta capa: ${shown}`;
    }
    [...controls.children].forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.id === id)));
  }

  capas.forEach((id, idx) => {
    const info = LAYER_INFO[id];
    if (!info) return;
    const btn = document.createElement('button');
    btn.textContent = info.label;
    btn.dataset.id = id;
    btn.setAttribute('aria-pressed', String(idx === 0));
    btn.addEventListener('click', () => applyLayer(id));
    controls.appendChild(btn);
  });

  applyLayer(capas[0]);
}
