// protein-layers.js — Unidad 5: capas de representación de una proteína real
// Estructura por defecto: ubiquitina (PDB 1UBQ, Vijay-Kumar, Bugg & Cook, 1987).
// Capa cuaternaria: hemoglobina (PDB 2HHB, Fermi, Perutz, Shaanan & Fourme, 1984),
// que sí tiene cuatro cadenas (dos alfa, dos beta) y por eso solo esa capa cambia
// de estructura. Ambos archivos son coordenadas reales descargadas de mirrors
// públicos de GitHub de las entradas del RCSB PDB, no datos sintéticos.

import { resolveProteinSource } from './mol-viewer.js';

const LAYER_INFO = {
  atomos: {
    label: 'Todos los átomos',
    apply: (viewer) => {
      viewer.setStyle({ hetflag: false }, { stick: { radius: 0.16, colorscheme: 'Jmol' } });
    },
    note: 'Cada átomo real de la cadena principal y las cadenas laterales, sin simplificar. A esta escala ya es difícil de leer, incluso en una proteína pequeña como la ubiquitina (76 aminoácidos, ~600 átomos sin contar hidrógenos).',
    structure: 'ubiquitina',
  },
  esqueleto: {
    label: 'Esqueleto (solo Cα)',
    apply: (viewer) => {
      viewer.setStyle({ atom: 'CA' }, { line: { linewidth: 3, colorscheme: 'Jmol' } });
    },
    note: 'Solo se conecta el carbono alfa de cada aminoácido: se pierde toda la información de las cadenas laterales, pero se ve con claridad la forma general de la cadena.',
    structure: 'ubiquitina',
  },
  listones: {
    label: 'Listones (ribbon)',
    apply: (viewer) => {
      viewer.setStyle({ hetflag: false }, { cartoon: { color: 'spectrum', thickness: 0.35, width: 0.8 } });
    },
    note: 'Ningún átomo se dibuja de forma explícita: 3Dmol.js reconoce la hélice y la lámina beta directamente de los registros HELIX/SHEET reales del archivo PDB, no las adivina.',
    structure: 'ubiquitina',
  },
  cuaternaria: {
    label: 'Subunidades (cuaternaria)',
    apply: (viewer) => {
      viewer.setStyle({ hetflag: false }, { cartoon: { colorscheme: 'chain', thickness: 0.35, width: 0.8 } });
      viewer.setStyle({ resn: 'HEM' }, { stick: { radius: 0.25, colorscheme: 'Jmol' }, sphere: { scale: 0.28, colorscheme: 'Jmol' } });
    },
    note: 'Hemoglobina real (PDB 2HHB): dos subunidades alfa y dos beta (una por color de cadena), cada una con su propio grupo hemo real (en varillas/esferas), unidas sin enlaces covalentes entre ellas.',
    structure: 'hemoglobina',
  },
};

export async function mount(container, params) {
  const { capas = ['atomos', 'esqueleto', 'listones'], contador_atomos } = params;
  container.innerHTML = '';

  const viewerBox = document.createElement('div');
  viewerBox.className = 'mol-viewer';
  viewerBox.style.height = '380px';
  container.appendChild(viewerBox);

  const controls = document.createElement('div');
  controls.className = 'mol-viewer__controls';
  container.appendChild(controls);

  const note = document.createElement('p');
  note.className = 'dim';
  note.style.fontSize = '0.85rem';
  container.appendChild(note);

  let atomCountEl = null;
  if (contador_atomos) {
    atomCountEl = document.createElement('div');
    atomCountEl.className = 'mol-viewer__measure-readout';
    container.appendChild(atomCountEl);
  }

  if (typeof window.$3Dmol === 'undefined') {
    viewerBox.innerHTML = '<div class="webgl-fallback">No se pudo cargar el motor 3D.</div>';
    return;
  }

  const viewer = window.$3Dmol.createViewer(viewerBox, { backgroundColor: '#000000', backgroundAlpha: 0 });
  const rawCache = {};
  const atomCountCache = {};

  async function loadStructure(name) {
    if (rawCache[name]) return rawCache[name];
    const source = resolveProteinSource(name);
    const res = await fetch(source);
    if (!res.ok) throw new Error(`No se pudo cargar ${source} (estado ${res.status})`);
    const raw = await res.text();
    rawCache[name] = raw;
    atomCountCache[name] = (raw.match(/^ATOM/gm) || []).length;
    return raw;
  }

  let currentStructure = null;

  async function applyLayer(id) {
    const info = LAYER_INFO[id];
    try {
      const raw = await loadStructure(info.structure);
      if (currentStructure !== info.structure) {
        viewer.clear();
        viewer.addModel(raw, 'pdb');
        currentStructure = info.structure;
      }
      viewer.setStyle({}, {});
      info.apply(viewer);
      viewer.zoomTo();
      viewer.render();
      note.textContent = info.note;
      if (atomCountEl) {
        const total = atomCountCache[info.structure];
        const shown = id === 'esqueleto' ? Math.round(total / 8) : id === 'atomos' ? total : id === 'cuaternaria' ? total : 0;
        atomCountEl.textContent = `Átomos reales en el archivo (${info.structure}): ${total} · dibujados explícitamente en esta capa: ${shown}`;
      }
      [...controls.children].forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.id === id)));
    } catch (e) {
      viewerBox.innerHTML = `<div class="webgl-fallback">No se pudo cargar la estructura de proteína (${e.message}). Sirve la app desde un servidor estático.</div>`;
      console.error(e);
    }
  }

  capas.forEach((id, idx) => {
    const info = LAYER_INFO[id];
    if (!info) return;
    const btn = document.createElement('button');
    btn.textContent = info.label;
    btn.dataset.id = id;
    btn.setAttribute('aria-pressed', String(idx === 0));
    btn.addEventListener('click', () => applyLayer(id));
    controls.appendChild(btn);
  });

  await applyLayer(capas[0]);
}
