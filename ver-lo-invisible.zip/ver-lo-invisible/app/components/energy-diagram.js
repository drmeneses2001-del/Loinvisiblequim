// energy-diagram.js — Unidad 3: diagrama de coordenada de reacción manipulable
// Ejes: x = coordenada de reacción (sin unidades físicas, es un resumen 1D de un
// camino multidimensional — simplificación explícita, ver texto del capítulo).
// y = energía relativa (unidades arbitrarias).

function buildPath(eReact, eaForward, eProd, catalystDrop) {
  // Puntos de control de una curva suave reactivos -> pico -> productos
  const x0 = 40, xPeak = 200, x1 = 360;
  const yBase = 220;
  const scale = 1.1;
  const yReact = yBase - eReact * scale;
  const yPeak = yBase - (eReact + eaForward - catalystDrop) * scale;
  const yProd = yBase - eProd * scale;
  return {
    d: `M ${x0} ${yReact} C ${(x0 + xPeak) / 2} ${yReact}, ${(x0 + xPeak) / 2} ${yPeak}, ${xPeak} ${yPeak}
        C ${(xPeak + x1) / 2} ${yPeak}, ${(xPeak + x1) / 2} ${yProd}, ${x1} ${yProd}`,
    yReact, yPeak, yProd, x0, xPeak, x1,
  };
}

export function mount(container, params) {
  container.innerHTML = '';
  const state = { eReact: 60, eaForward: 90, eProd: 20, catalyst: false };

  const svgHost = document.createElement('div');
  container.appendChild(svgHost);

  const controls = document.createElement('div');
  container.appendChild(controls);

  function sliderRow(label, key, min, max) {
    const row = document.createElement('div');
    row.className = 'slider-row';
    const lab = document.createElement('span');
    lab.style.cssText = 'min-width:9em;font-size:0.85rem;color:var(--ink-dim);';
    lab.textContent = label;
    const input = document.createElement('input');
    input.type = 'range'; input.min = String(min); input.max = String(max); input.value = String(state[key]);
    const out = document.createElement('output');
    input.addEventListener('input', () => { state[key] = Number(input.value); out.textContent = input.value; redraw(); });
    out.textContent = String(state[key]);
    row.appendChild(lab); row.appendChild(input); row.appendChild(out);
    controls.appendChild(row);
  }
  sliderRow('Energía de activación (Ea)', 'eaForward', 20, 140);
  sliderRow('Energía de productos', 'eProd', -40, 100);

  const catBtn = document.createElement('button');
  catBtn.textContent = 'Añadir catalizador';
  catBtn.style.cssText = 'background:var(--bg-panel-raised);border:1px solid var(--border-soft);color:var(--ink);padding:0.5rem 1rem;border-radius:999px;min-height:44px;margin-top:0.4rem;';
  catBtn.addEventListener('click', () => {
    state.catalyst = !state.catalyst;
    catBtn.textContent = state.catalyst ? '✓ Catalizador activo (quitar)' : 'Añadir catalizador';
    redraw();
  });
  controls.appendChild(catBtn);

  const readout = document.createElement('p');
  readout.style.cssText = 'font-size:0.85rem;color:var(--ink-dim);margin-top:0.6rem;';
  container.appendChild(readout);

  function redraw() {
    const drop = state.catalyst ? Math.min(state.eaForward * 0.5, 45) : 0;
    const p = buildPath(state.eReact, state.eaForward, state.eProd, drop);
    const deltaH = (state.eProd - state.eReact).toFixed(0);
    const eaEffective = (state.eaForward - drop).toFixed(0);
    svgHost.innerHTML = `
      <svg viewBox="0 0 400 260" width="100%" height="260">
        <line x1="30" y1="230" x2="380" y2="230" stroke="#26324A" stroke-width="1"/>
        <text x="205" y="252" font-size="11" fill="#93A0B8" text-anchor="middle">coordenada de reacción</text>
        <text x="15" y="120" font-size="11" fill="#93A0B8" transform="rotate(-90 15 120)" text-anchor="middle">energía</text>
        <path d="${p.d}" fill="none" stroke="${state.catalyst ? '#6EE7B7' : '#F2B33D'}" stroke-width="3"/>
        <line x1="${p.x0}" y1="${p.yReact}" x2="${p.x0}" y2="230" stroke="#26324A" stroke-dasharray="3,3"/>
        <line x1="${p.x1}" y1="${p.yProd}" x2="${p.x1}" y2="230" stroke="#26324A" stroke-dasharray="3,3"/>
        <text x="${p.x0}" y="${p.yReact - 8}" font-size="11" fill="#E8EDF5" text-anchor="middle">reactivos</text>
        <text x="${p.x1}" y="${p.yProd - 8}" font-size="11" fill="#E8EDF5" text-anchor="middle">productos</text>
        <text x="${p.xPeak}" y="${p.yPeak - 10}" font-size="11" fill="${state.catalyst ? '#6EE7B7' : '#F2B33D'}" text-anchor="middle">estado de transición</text>
      </svg>
    `;
    readout.innerHTML = `Ea efectiva: <strong>${eaEffective}</strong> · ΔH de la reacción: <strong>${deltaH}</strong> ${deltaH < 0 ? '(exotérmica: libera energía)' : '(endotérmica: absorbe energía)'}. ${state.catalyst ? 'El catalizador bajó el pico sin mover los extremos: reactivos y productos quedan igual.' : ''}`;
  }
  redraw();
}
