// scale-slider.js — Unidad 0: deslizador de escalas de 1 m a 10^-15 m
const STOPS = [
  { label: 'Una persona', size: '≈ 1,7 m', order: 0, instrumento: 'El ojo, sin ayuda', repr: '—' },
  { label: 'Una hormiga', size: '≈ 5 mm', order: -2.3, instrumento: 'El ojo, de cerca', repr: '—' },
  { label: 'Una célula humana', size: '≈ 10–20 µm', order: -5, instrumento: 'Microscopio óptico', repr: 'Diagramas esquemáticos' },
  { label: 'Un virus', size: '≈ 100 nm', order: -7, instrumento: 'Microscopio electrónico', repr: 'Modelos de superficie' },
  { label: 'Una proteína plegada', size: '≈ 5 nm', order: -8.3, instrumento: 'Cristalografía de rayos X / crio-EM', repr: 'Diagramas de listones (Unidad 5)' },
  { label: 'Una molécula pequeña (agua)', size: '≈ 0,3 nm', order: -9.5, instrumento: 'Espectroscopía, difracción', repr: 'Fórmulas y modelos 3D (Unidades 2–4)' },
  { label: 'Un átomo', size: '≈ 0,1–0,3 nm', order: -10, instrumento: 'Microscopía de efecto túnel (indirecta)', repr: 'Modelos atómicos (Unidad 1)' },
  { label: 'Un núcleo atómico', size: '≈ 1–10 fm (10⁻¹⁵ m)', order: -14.5, instrumento: 'Dispersión de partículas (experimentos tipo Rutherford)', repr: 'Punto o esfera diminuta en los diagramas' },
];

export function mount(container, params) {
  container.innerHTML = '';
  const wrap = document.createElement('div');

  const display = document.createElement('div');
  display.style.marginBottom = '0.8rem';
  wrap.appendChild(display);

  const row = document.createElement('div');
  row.className = 'slider-row';
  const input = document.createElement('input');
  input.type = 'range';
  input.min = '0';
  input.max = String(STOPS.length - 1);
  input.step = '1';
  input.value = '0';
  const output = document.createElement('output');
  row.appendChild(input);
  row.appendChild(output);
  wrap.appendChild(row);

  function render(i) {
    const s = STOPS[i];
    display.innerHTML = `
      <h3 style="margin-bottom:0.2rem">${s.label}</h3>
      <p class="dim" style="margin:0 0 0.3rem 0">Tamaño aproximado: <strong>${s.size}</strong></p>
      <p class="dim" style="margin:0 0 0.3rem 0">Cómo se estudia: ${s.instrumento}</p>
      <p class="dim" style="margin:0">Representación típica en química: ${s.repr}</p>
    `;
    output.textContent = `10^${s.order}`;
  }

  input.addEventListener('input', () => render(Number(input.value)));
  render(0);
  container.appendChild(wrap);

  const note = document.createElement('p');
  note.className = 'dim';
  note.style.fontSize = '0.78rem';
  note.style.marginTop = '0.6rem';
  note.textContent = 'Los tamaños son órdenes de magnitud aproximados, no medidas exactas de un objeto particular.';
  container.appendChild(note);
}
