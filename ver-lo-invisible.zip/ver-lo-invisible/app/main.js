// main.js — router y motor de renderizado de "Ver lo Invisible"
import { renderMarkdown } from './markdown-lite.js';
import { createJohnstoneMini, LETRA_A_NIVEL } from './components/johnstone-mini.js';

import * as molViewer from './components/mol-viewer.js';
import * as representationPanel from './components/representation-panel.js';
import * as ringToggle from './components/ring-toggle.js';
import * as proteinLayers from './components/protein-layers.js';
import * as atomModelCompare from './components/atom-model-compare.js';
import * as orbitalCloud from './components/orbital-cloud.js';
import * as scaleSlider from './components/scale-slider.js';
import * as johnstoneTriangle from './components/johnstone-triangle.js';
import * as equationBalancer from './components/equation-balancer.js';
import * as curvedArrows from './components/curved-arrows.js';
import * as energyDiagram from './components/energy-diagram.js';
import * as comparisonTable from './components/comparison-table.js';
import * as bibliographyTable from './components/bibliography-table.js';

const REGISTRY = {
  'mol-viewer': molViewer,
  'representation-panel': representationPanel,
  'ring-toggle': ringToggle,
  'protein-layers': proteinLayers,
  'atom-model-compare': atomModelCompare,
  'orbital-cloud': orbitalCloud,
  'scale-slider': scaleSlider,
  'johnstone-triangle': johnstoneTriangle,
  'equation-balancer': equationBalancer,
  'curved-arrows': curvedArrows,
  'energy-diagram': energyDiagram,
  'comparison-table': comparisonTable,
  'bibliography-table': bibliographyTable,
};

const mainEl = document.getElementById('app-main');
const tabsEl = document.getElementById('unit-tabs');
const miniHost = document.getElementById('johnstone-mini-host');
const johnstoneMini = createJohnstoneMini(miniHost);

let chapterIndex = [];

function renderActivity(content) {
  const card = document.createElement('div');
  card.className = 'activity-card';
  const items = content
    .split('\n')
    .map((l) => l.replace(/^\d+\.\s*/, '').trim())
    .filter(Boolean);
  card.innerHTML = '<ol>' + items.map((it) => `<li>${it}</li>`).join('') + '</ol>';
  return card;
}

async function renderFence(block) {
  const wrap = document.createElement('div');
  if (block.kind === 'interactivo') {
    wrap.className = 'interactive-slot';
    const title = document.createElement('div');
    title.className = 'interactive-slot__title';
    title.innerHTML = `<span>Interactivo</span>`;
    wrap.appendChild(title);
    const mountPoint = document.createElement('div');
    wrap.appendChild(mountPoint);
    const mod = REGISTRY[block.sub];
    if (mod && typeof mod.mount === 'function') {
      try {
        await mod.mount(mountPoint, block.params || {});
      } catch (e) {
        mountPoint.innerHTML = `<p class="dim">No se pudo cargar este interactivo (${block.sub}): ${e.message}</p>`;
        console.error(e);
      }
    } else {
      mountPoint.innerHTML = `<p class="dim">Componente "${block.sub}" no registrado todavía.</p>`;
    }
    return wrap;
  }
  if (block.kind === 'actividad') {
    return renderActivity(block.content);
  }
  if (block.kind === 'badge') {
    const div = document.createElement('div');
    const cls = block.sub || 'convencion';
    const label = { convencion: 'Convención', simplificacion: 'Simplificación deliberada', supuesto: 'Supuesto / modelo' }[cls] || cls;
    div.className = `badge badge--${cls}`;
    div.innerHTML = `<span class="badge__label">${label}</span>${block.content}`;
    return div;
  }
  wrap.innerHTML = renderMarkdown(block.content || '');
  return wrap;
}

async function renderSection(section) {
  const box = document.createElement('div');
  box.className = 'section-block';
  box.dataset.letra = section.letra || '';

  if (section.titulo) {
    const label = document.createElement('div');
    label.className = 'section-block__label';
    label.textContent = section.letra ? `${section.letra}.` : '';
    box.appendChild(label);
    const h2 = document.createElement('h2');
    h2.textContent = section.titulo;
    box.appendChild(h2);
  }

  const bodyHost = document.createElement('div');
  for (const block of section.blocks) {
    if (block.type === 'text') {
      const div = document.createElement('div');
      div.innerHTML = renderMarkdown(block.markdown);
      bodyHost.appendChild(div);
    } else {
      bodyHost.appendChild(await renderFence(block));
    }
  }

  if (section.letra === 'G') {
    const exp = document.createElement('div');
    exp.className = 'expandable';
    const toggle = document.createElement('button');
    toggle.className = 'expandable__toggle';
    toggle.innerHTML = '▸ Para quien quiera ir más allá';
    const body = document.createElement('div');
    body.className = 'expandable__body';
    body.appendChild(bodyHost);
    toggle.addEventListener('click', () => {
      exp.classList.toggle('is-open');
      toggle.innerHTML = (exp.classList.contains('is-open') ? '▾' : '▸') + ' Para quien quiera ir más allá';
    });
    exp.appendChild(toggle);
    exp.appendChild(body);
    box.innerHTML = '';
    box.appendChild(exp);
  } else {
    box.appendChild(bodyHost);
  }

  return box;
}

function setupJohnstoneObserver() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const letra = entry.target.dataset.letra;
          const nivel = LETRA_A_NIVEL[letra];
          if (nivel) johnstoneMini.setLevel(nivel);
        }
      });
    },
    { rootMargin: '-40% 0px -50% 0px' }
  );
  document.querySelectorAll('.section-block').forEach((el) => observer.observe(el));
}

function renderTabs(current) {
  tabsEl.innerHTML = '';
  chapterIndex.forEach((ch) => {
    const btn = document.createElement('button');
    btn.className = 'unit-tab';
    btn.textContent = `${ch.unidad} · ${ch.titulo}`;
    btn.setAttribute('aria-current', String(ch.file === current));
    btn.addEventListener('click', () => {
      window.location.hash = `#/${ch.file.replace('.json', '')}`;
    });
    tabsEl.appendChild(btn);
  });
}

async function renderChapter(file) {
  mainEl.innerHTML = '<p class="dim">Cargando…</p>';
  const res = await fetch(`content/json/${file}`);
  const data = await res.json();

  mainEl.innerHTML = '';
  const header = document.createElement('div');
  header.className = 'chapter-header';
  header.innerHTML = `<div class="kicker">Unidad ${data.meta.unidad}</div><h1>${data.meta.titulo}</h1>`;
  mainEl.appendChild(header);

  for (const section of data.sections) {
    mainEl.appendChild(await renderSection(section));
  }

  const idx = chapterIndex.findIndex((c) => c.file === file);
  const footer = document.createElement('div');
  footer.className = 'chapter-nav-footer';
  const prev = document.createElement('button');
  const next = document.createElement('button');
  prev.textContent = '← Anterior';
  next.textContent = 'Siguiente →';
  prev.disabled = idx <= 0;
  next.disabled = idx === -1 || idx >= chapterIndex.length - 1;
  prev.addEventListener('click', () => {
    window.location.hash = `#/${chapterIndex[idx - 1].file.replace('.json', '')}`;
  });
  next.addEventListener('click', () => {
    window.location.hash = `#/${chapterIndex[idx + 1].file.replace('.json', '')}`;
  });
  footer.appendChild(prev);
  footer.appendChild(next);
  mainEl.appendChild(footer);

  renderTabs(file);
  setupJohnstoneObserver();
  window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' });
}

function currentFileFromHash() {
  const h = window.location.hash.replace('#/', '');
  if (!h) return null;
  return `${h}.json`;
}

async function route() {
  let file = currentFileFromHash();
  if (!file || !chapterIndex.find((c) => c.file === file)) {
    file = chapterIndex[0].file;
    window.location.hash = `#/${file.replace('.json', '')}`;
    return; // el cambio de hash disparará hashchange -> route() de nuevo
  }
  await renderChapter(file);
}

async function init() {
  const res = await fetch('content/json/index.json');
  chapterIndex = await res.json();
  window.addEventListener('hashchange', route);
  await route();
}

init();
