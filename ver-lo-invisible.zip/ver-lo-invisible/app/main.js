// main.js — router y motor de renderizado de "Ver lo Invisible"
//
// IMPORTANTE: todos los componentes se cargan con import() dinámico (no como
// imports estáticos arriba del archivo). Esto es deliberado: si un solo
// componente tuviera un error, un import estático haría fallar TODO el
// archivo en silencio (pantalla atascada en "Cargando…" sin ninguna pista).
// Con import() dinámico, un fallo queda contenido a ese componente y se
// muestra en pantalla, en vez de tumbar toda la aplicación.

import { renderMarkdown } from './markdown-lite.js';

const COMPONENT_LOADERS = {
  'mol-viewer': () => import('./components/mol-viewer.js'),
  'representation-panel': () => import('./components/representation-panel.js'),
  'ring-toggle': () => import('./components/ring-toggle.js'),
  'protein-layers': () => import('./components/protein-layers.js'),
  'atom-model-compare': () => import('./components/atom-model-compare.js'),
  'orbital-cloud': () => import('./components/orbital-cloud.js'),
  'scale-slider': () => import('./components/scale-slider.js'),
  'johnstone-triangle': () => import('./components/johnstone-triangle.js'),
  'equation-balancer': () => import('./components/equation-balancer.js'),
  'curved-arrows': () => import('./components/curved-arrows.js'),
  'energy-diagram': () => import('./components/energy-diagram.js'),
  'comparison-table': () => import('./components/comparison-table.js'),
  'bibliography-table': () => import('./components/bibliography-table.js'),
};

const LETRA_A_NIVEL = { A: 'macro', B: 'simbolico', C: 'simbolico', D: 'submicro', E: 'submicro', F: 'simbolico', G: 'submicro', H: null };

let mainEl, tabsEl, miniHost, johnstoneMini;
let chapterIndex = [];

function renderActivity(content) {
  const card = document.createElement('div');
  card.className = 'activity-card';
  const items = content
    .split('\n')
    .map((l) => l.replace(/^\d+\.\s*/, '').trim())
    .filter(Boolean);
  card.innerHTML = '<ol>' + items.map((it) => `<li>${it}</li>`).join('') + '</ol>';
  return card;
}

async function renderFence(block) {
  const wrap = document.createElement('div');
  if (block.kind === 'interactivo') {
    wrap.className = 'interactive-slot';
    const title = document.createElement('div');
    title.className = 'interactive-slot__title';
    title.innerHTML = `<span>Interactivo</span>`;
    wrap.appendChild(title);
    const mountPoint = document.createElement('div');
    wrap.appendChild(mountPoint);
    const loader = COMPONENT_LOADERS[block.sub];
    if (loader) {
      try {
        const mod = await loader();
        await mod.mount(mountPoint, block.params || {});
      } catch (e) {
        mountPoint.innerHTML = `<p class="dim">No se pudo cargar este interactivo (${block.sub}).</p><pre style="white-space:pre-wrap;font-size:0.75rem;color:#93A0B8;">${(e && e.stack) || e}</pre>`;
        console.error('Error en componente', block.sub, e);
      }
    } else {
      mountPoint.innerHTML = `<p class="dim">Componente "${block.sub}" no registrado todavía.</p>`;
    }
    return wrap;
  }
  if (block.kind === 'actividad') {
    return renderActivity(block.content);
  }
  if (block.kind === 'badge') {
    const div = document.createElement('div');
    const cls = block.sub || 'convencion';
    const label = { convencion: 'Convención', simplificacion: 'Simplificación deliberada', supuesto: 'Supuesto / modelo' }[cls] || cls;
    div.className = `badge badge--${cls}`;
    div.innerHTML = `<span class="badge__label">${label}</span>${block.content}`;
    return div;
  }
  wrap.innerHTML = renderMarkdown(block.content || '');
  return wrap;
}

async function renderSection(section) {
  const box = document.createElement('div');
  box.className = 'section-block';
  box.dataset.letra = section.letra || '';

  if (section.titulo) {
    const label = document.createElement('div');
    label.className = 'section-block__label';
    label.textContent = section.letra ? `${section.letra}.` : '';
    box.appendChild(label);
    const h2 = document.createElement('h2');
    h2.textContent = section.titulo;
    box.appendChild(h2);
  }

  const bodyHost = document.createElement('div');
  for (const block of section.blocks) {
    if (block.type === 'text') {
      const div = document.createElement('div');
      div.innerHTML = renderMarkdown(block.markdown);
      bodyHost.appendChild(div);
    } else {
      bodyHost.appendChild(await renderFence(block));
    }
  }

  if (section.letra === 'G') {
    const exp = document.createElement('div');
    exp.className = 'expandable';
    const toggle = document.createElement('button');
    toggle.className = 'expandable__toggle';
    toggle.innerHTML = '▸ Para quien quiera ir más allá';
    const body = document.createElement('div');
    body.className = 'expandable__body';
    body.appendChild(bodyHost);
    toggle.addEventListener('click', () => {
      exp.classList.toggle('is-open');
      toggle.innerHTML = (exp.classList.contains('is-open') ? '▾' : '▸') + ' Para quien quiera ir más allá';
    });
    exp.appendChild(toggle);
    exp.appendChild(body);
    box.innerHTML = '';
    box.appendChild(exp);
  } else {
    box.appendChild(bodyHost);
  }

  return box;
}

function setupJohnstoneObserver() {
  if (!johnstoneMini) return;
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const letra = entry.target.dataset.letra;
          const nivel = LETRA_A_NIVEL[letra];
          if (nivel) johnstoneMini.setLevel(nivel);
        }
      });
    },
    { rootMargin: '-40% 0px -50% 0px' }
  );
  document.querySelectorAll('.section-block').forEach((el) => observer.observe(el));
}

function renderTabs(current) {
  tabsEl.innerHTML = '';
  chapterIndex.forEach((ch) => {
    const btn = document.createElement('button');
    btn.className = 'unit-tab';
    btn.textContent = `${ch.unidad} · ${ch.titulo}`;
    btn.setAttribute('aria-current', String(ch.file === current));
    btn.addEventListener('click', () => {
      window.location.hash = `#/${ch.file.replace('.json', '')}`;
    });
    tabsEl.appendChild(btn);
  });
}

async function renderChapter(file) {
  mainEl.innerHTML = '<p class="dim">Cargando…</p>';
  const res = await fetch(`content/json/${file}`);
  if (!res.ok) throw new Error(`content/json/${file} respondió con estado ${res.status}`);
  const data = await res.json();

  mainEl.innerHTML = '';
  const header = document.createElement('div');
  header.className = 'chapter-header';
  header.innerHTML = `<div class="kicker">Unidad ${data.meta.unidad}</div><h1>${data.meta.titulo}</h1>`;
  mainEl.appendChild(header);

  for (const section of data.sections) {
    mainEl.appendChild(await renderSection(section));
  }

  const idx = chapterIndex.findIndex((c) => c.file === file);
  const footer = document.createElement('div');
  footer.className = 'chapter-nav-footer';
  const prev = document.createElement('button');
  const next = document.createElement('button');
  prev.textContent = '← Anterior';
  next.textContent = 'Siguiente →';
  prev.disabled = idx <= 0;
  next.disabled = idx === -1 || idx >= chapterIndex.length - 1;
  prev.addEventListener('click', () => {
    window.location.hash = `#/${chapterIndex[idx - 1].file.replace('.json', '')}`;
  });
  next.addEventListener('click', () => {
    window.location.hash = `#/${chapterIndex[idx + 1].file.replace('.json', '')}`;
  });
  footer.appendChild(prev);
  footer.appendChild(next);
  mainEl.appendChild(footer);

  renderTabs(file);
  setupJohnstoneObserver();
  window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' });
}

function currentFileFromHash() {
  const h = window.location.hash.replace('#/', '');
  if (!h) return null;
  return `${h}.json`;
}

async function route() {
  try {
    let file = currentFileFromHash();
    if (!file || !chapterIndex.find((c) => c.file === file)) {
      file = chapterIndex[0].file;
      window.location.hash = `#/${file.replace('.json', '')}`;
      return; // el cambio de hash disparará hashchange -> route() de nuevo
    }
    await renderChapter(file);
  } catch (err) {
    showFatalError(err);
  }
}

function showFatalError(err) {
  console.error(err);
  const target = mainEl || document.body;
  target.innerHTML = `
    <div style="border:1px solid #B4463C;border-radius:8px;padding:1rem;margin:1rem;font-family:sans-serif;color:#E8EDF5;">
      <h2 style="color:#F2B33D;margin-top:0;">No se pudo iniciar la app</h2>
      <p>Ocurrió un error al cargar. Copia este mensaje y compártelo:</p>
      <pre style="white-space:pre-wrap;word-break:break-word;background:#06090F;padding:0.8rem;border-radius:6px;font-size:0.8rem;">${(err && err.stack) || err}</pre>
    </div>
  `;
}

async function init() {
  try {
    mainEl = document.getElementById('app-main');
    tabsEl = document.getElementById('unit-tabs');
    miniHost = document.getElementById('johnstone-mini-host');
    if (!mainEl || !tabsEl || !miniHost) {
      throw new Error('No se encontraron los elementos base del HTML (app-main / unit-tabs / johnstone-mini-host). Revisa que index.html coincida con esta versión de main.js.');
    }
    try {
      const { createJohnstoneMini } = await import('./components/johnstone-mini.js');
      johnstoneMini = createJohnstoneMini(miniHost);
    } catch (e) {
      console.error('No se pudo cargar el indicador de Johnstone (no es crítico):', e);
    }

    const res = await fetch('content/json/index.json');
    if (!res.ok) throw new Error(`index.json respondió con estado ${res.status}`);
    chapterIndex = await res.json();
    if (!Array.isArray(chapterIndex) || !chapterIndex.length) {
      throw new Error('content/json/index.json se cargó pero está vacío o mal formado.');
    }
    window.addEventListener('hashchange', route);
    await route();
  } catch (err) {
    showFatalError(err);
  }
}

init();
