---
unidad: 1
titulo: Representaciones atómicas
molecula_central: hidrogeno
niveles: [macro, submicro, simbolico]
---

## A. Lo que vemos

Un trozo de carbón, opaco y negro. Un diamante, transparente y durísimo. Ambos son carbono puro. Si el átomo de carbono fuera "una cosa con aspecto propio", ¿cómo puede dar lugar a dos materiales tan distintos? La respuesta no está en el átomo aislado sino en cómo se conectan entre sí (lo veremos en la Unidad 2) — pero antes hace falta preguntar: ¿qué es, para la química, "un átomo de carbono"?

## B. La representación

A lo largo de la historia, la química ha dibujado el átomo de maneras muy distintas, y **cada una responde a un problema experimental concreto**, no a una moda:

| Modelo | Año aprox. | Qué explica |
|---|---|---|
| Esfera indivisible (Dalton) | 1803 | Por qué los compuestos tienen proporciones fijas de elementos |
| "Pudín de pasas" (Thomson) | 1904 | La existencia del electrón, de carga negativa |
| Núcleo pequeño y denso (Rutherford) | 1911 | Por qué partículas alfa rebotaban al chocar con una lámina de oro |
| Electrones en órbitas definidas (Bohr) | 1913 | Por qué los átomos emiten luz en colores (líneas) específicos, no en cualquier color |
| Nube de probabilidad orbital | 1920s en adelante | Las formas de los enlaces y las moléculas |

::: interactivo atom-model-compare {atomo: "hidrogeno"}
:::

## C. Una metáfora para pensarlo

Ningún modelo del átomo es "una foto", del mismo modo que ningún mapa es un territorio a escala 1:1. Son **mapas hechos con propósitos distintos** del mismo territorio invisible: un mapa de carreteras sirve para conducir; uno topográfico, para saber dónde hay pendiente; ninguno reemplaza al otro, y ninguno "es" la ciudad. El modelo de Bohr sirve para entender por qué el hidrógeno emite luz de colores concretos; la nube orbital sirve para entender por qué el agua tiene la forma que tiene. Usar el mapa equivocado para la pregunta equivocada es la fuente de casi todos los errores conceptuales de este capítulo.

*Límite de la metáfora: un cartógrafo puede mirar la ciudad desde un avión. Nadie ha "mirado" jamás un átomo con luz visible: cada modelo se dedujo indirectamente, a partir de cómo se comportaba la materia en experimentos (dispersión de partículas, espectros de emisión, difracción).*

## D. Qué pasa realmente (nivel submicroscópico)

Un átomo de hidrógeno tiene un núcleo (un protón) de aproximadamente 10⁻¹⁵ m de diámetro, rodeado por una región donde es probable encontrar a su electrón, de aproximadamente 10⁻¹⁰ m de diámetro. La diferencia de tamaño es de un factor de alrededor de 100.000.

Si el núcleo fuera del tamaño de una canica de 1 cm, el átomo completo tendría aproximadamente el tamaño de un campo de fútbol de unos 1000 m — el electrón estaría "en algún lugar" de ese campo, y la mayor parte del espacio no contendría materia en el sentido de masa concentrada.

🟪 *Supuesto/modelo: el electrón no viaja por una trayectoria definida como un planeta. Lo que la mecánica cuántica permite calcular es una función de onda cuyo cuadrado da la probabilidad de encontrar al electrón en cada punto del espacio. La "nube" que se dibuja no es el electrón difuminado; es un mapa de probabilidades acumuladas a lo largo del tiempo.*

## E. Lo que estos dibujos te hacen creer

- **El modelo de Bohr** invita a pensar que "los electrones orbitan como planetas alrededor de un sol", con trayectorias circulares definidas. 🟨 Es una simplificación útil para explicar los espectros de líneas del hidrógeno, pero no describe cómo se mueve realmente el electrón.
- **Los dibujos a escala** (núcleo grande dentro de un átomo pequeño) inducen a pensar que el átomo es "mayormente sólido". En realidad, en términos de masa concentrada, es mayormente espacio vacío: casi toda la masa está en un núcleo diminuto.
- **Los colores en los diagramas** (esferas rojas, azules, etc.) inducen a pensar que "los átomos tienen color". Los átomos no tienen color en el sentido cotidiano; el color es una propiedad que surge de cómo interactúa la luz con conjuntos enormes de átomos o moléculas, no de un átomo aislado.
- **Extrapolar propiedades macroscópicas al átomo individual**: preguntarse "¿es maleable un átomo de cobre?" es una pregunta mal planteada, porque la maleabilidad es una propiedad de un conjunto ordenado de átomos de cobre (una red metálica), no de un átomo aislado. Este error está documentado en la investigación de Ben-Zvi, Eylon y Silberstein (1986) — ver bibliografía.

## F. Compara: ninguna es "la verdadera"

::: interactivo atom-model-compare {modo: "comparacion-lado-a-lado", atomos: ["hidrogeno","helio","carbono"]}
:::

Observa que el modelo de Bohr y la nube orbital "coinciden" en algo (el número de electrones) y difieren radicalmente en otra cosa (si hay o no una trayectoria definida). Esa coincidencia parcial es exactamente lo que hace útil a cada modelo dentro de su propio propósito, y engañoso si se usa fuera de él.

## G. Para quien quiera ir más allá

El modelo de Bohr sigue enseñándose porque predice con notable precisión las líneas espectrales del hidrógeno (un átomo de un solo electrón) usando matemáticas relativamente simples, aunque falla para átomos con más de un electrón. La razón profunda por la que no se puede hablar de una "trayectoria" del electrón está relacionada con el principio de incertidumbre de Heisenberg: no es una limitación de nuestros instrumentos, sino una propiedad de cómo se comportan las partículas a esa escala. Lo que llamamos "imagen" de un microscopio de efecto túnel (STM) tampoco es una fotografía óptica: es un mapa de una corriente eléctrica que depende de la distancia entre una punta y la superficie, reconstruido después como imagen.

## H. Actividad

::: actividad
1. ¿Qué pregunta responde bien el modelo de Bohr y qué pregunta responde mal?
2. Explica con tus palabras por qué "el átomo tiene color rojo" es una frase sin sentido estricto, aunque los dibujos lo sugieran.
3. Un compañero dice: "un átomo de cobre debe ser brillante y maleable, porque el cobre lo es". ¿Qué le responderías?
:::
