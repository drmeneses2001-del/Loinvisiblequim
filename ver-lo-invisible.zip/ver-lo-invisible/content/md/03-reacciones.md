---
unidad: 3
titulo: Representaciones de reacciones
molecula_central: metano-combustion
niveles: [macro, submicro, simbolico]
---

## A. Lo que vemos

Una vela se consume lentamente mientras arde. Una tableta antiácida, al caer en agua, produce burbujas. En ambos casos, algo desaparece y algo nuevo aparece, aunque no podamos ver el instante exacto en que ocurre el cambio.

## B. La representación

Existen al menos tres representaciones distintas para una misma reacción, cada una respondiendo una pregunta diferente:

1. **Ecuación balanceada:** CH₄ + 2 O₂ → CO₂ + 2 H₂O — responde "¿qué entra y qué sale, y en qué proporciones?".
2. **Mecanismo con flechas curvas:** responde "¿cómo se mueven los electrones, paso a paso, para que eso ocurra?".
3. **Diagrama de coordenada de reacción (energía):** responde "¿cuánta energía hace falta para que ocurra, y cuánta se libera o se absorbe?".

::: interactivo equation-balancer {reaccion: "combustion-metano"}
:::

🟦 *Convención: los coeficientes de una ecuación balanceada cuentan partículas (o moles de partículas), nunca átomos sueltos dentro de una molécula. "2 H₂O" son dos moléculas de agua completas; no confundir con "H₄O₂".*

## C. Una metáfora para pensarlo

Piensa en una cena, una coreografía y un mapa de altitudes. La ecuación balanceada es como la lista de ingredientes y el plato final de una receta: te dice qué entra y qué sale, pero no el proceso paso a paso. El mecanismo con flechas curvas es como la coreografía de un baile: muestra, paso a paso, quién se mueve y hacia dónde (en este caso, los electrones). El diagrama de energía es como el perfil de altitud de una ruta de montaña: muestra si hay que subir antes de bajar, y qué tan alto es el punto más difícil del camino. Las tres describen el mismo viaje desde ángulos distintos.

*Límite de la metáfora: en una coreografía real hay un coreógrafo. En una reacción química nadie dirige a los electrones: el mecanismo describe una redistribución que ocurre porque es energéticamente favorable, no porque "sigue instrucciones".*

## D. Qué pasa realmente (nivel submicroscópico)

En un gas o líquido a temperatura ambiente, las moléculas chocan miles de millones de veces por segundo (orden de magnitud). La inmensa mayoría de esas colisiones no produce ninguna reacción: solo cuando dos moléculas chocan con suficiente energía y con la orientación adecuada, los electrones se reorganizan y se forman nuevos enlaces. Ese instante de reorganización —llamado estado de transición— es extremadamente breve (del orden de 10⁻¹³ s, orden de magnitud) y no corresponde a ninguna molécula estable que se pueda aislar.

::: interactivo curved-arrows {reaccion: "acido-base"}
:::

## E. Lo que estos dibujos te hacen creer

- **La ecuación balanceada** puede sugerir que los reactivos "desaparecen" y los productos "aparecen" todos a la vez, de forma instantánea y ordenada. En realidad es un resumen estadístico de un proceso que ocurre de forma continua y probabilística.
- **Los coeficientes** suelen confundirse con subíndices: "2 H₂O" (dos moléculas de agua) no es lo mismo que "H₄O₂" (una fórmula distinta, que no representa al agua).
- **Las flechas curvas** inducen a pensar que la flecha representa el movimiento de un átomo completo. En realidad, por convención, cada flecha curva sigue el movimiento de un par de electrones, no de núcleos atómicos — un error documentado en estudiantes incluso avanzados por Bhattacharyya y Bodner (2005).
- **El diagrama de energía** puede sugerir que la molécula "sube" físicamente una montaña, o que un catalizador "le da energía extra" a la reacción. En realidad, el eje vertical representa energía, no posición, y un catalizador funciona abriendo un camino alternativo con una barrera más baja, sin cambiar la energía de reactivos ni de productos.

## F. Compara: ninguna es "la verdadera"

::: interactivo energy-diagram {reaccion: "generica", manipulable: true}
:::

Prueba a mover el punto de energía de activación y a activar el catalizador: notarás que el catalizador baja el punto más alto del camino sin mover los extremos (reactivos y productos). Eso es exactamente lo que la ecuación balanceada no puede mostrar (no dice nada sobre velocidad ni sobre caminos alternativos) y lo que el mecanismo de flechas curvas tampoco muestra directamente (no dice cuánta energía hace falta).

## G. Para quien quiera ir más allá

Las flechas curvas representan, más precisamente, el movimiento de electrones entre orbitales: una flecha que sale de un par solitario o de un enlace y "apunta" hacia otro átomo describe la formación de un nuevo enlace o el desplazamiento de densidad electrónica existente. Muchas reacciones reales no ocurren en un solo paso, como en nuestro ejemplo simplificado, sino en varios pasos con intermediarios que pueden ser lo bastante estables como para detectarse experimentalmente, aunque no aislarse.

## H. Actividad

::: actividad
1. ¿Qué información da la ecuación balanceada que no da el diagrama de energía, y viceversa?
2. Explica por qué "el catalizador le da energía a la reacción" es una descripción incorrecta, usando el diagrama de energía.
3. Un compañero interpreta una flecha curva como "el átomo de hidrógeno se mueve hacia allá". ¿Qué le explicarías?
:::
