---
unidad: 2
titulo: Representaciones moleculares
molecula_central: etanol
molecula_contraste: dimetileter
niveles: [macro, submicro, simbolico]
---

## A. Lo que vemos

Un poco de alcohol (etanol) sobre la piel se evapora rápido y deja una sensación de frío. El azúcar se disuelve en el té sin dejar rastro visible. En ambos casos, algo sucede a una escala que no podemos ver directamente.

## B. La representación

La misma molécula puede escribirse de al menos cinco maneras distintas, cada una mostrando y ocultando información distinta. Usaremos el **etanol** (el alcohol de las bebidas y del gel desinfectante) como ejemplo central:

::: interactivo representation-panel {molecula: "etanol", contraste: "dimetileter"}
:::

1. **Fórmula molecular:** C₂H₆O — dice de qué átomos y cuántos está hecha, pero nada sobre cómo se conectan.
2. **Fórmula estructural desarrollada:** muestra todos los enlaces, átomo por átomo.
3. **Fórmula condensada:** CH₃CH₂OH — un atajo de escritura que agrupa átomos por grupo.
4. **Fórmula esqueleto (línea-ángulo):** 🟦 convención en la que los átomos de carbono y los hidrógenos unidos a carbono se omiten; cada vértice y extremo de línea es un carbono.
5. **Modelo 3D:** bolas y varillas (muestra enlaces y ángulos) o espacio-lleno (muestra el volumen real que ocupa la molécula).

## C. Una metáfora para pensarlo

Piensa en los distintos "idiomas" con los que se puede describir un mismo edificio. La dirección postal (C₂H₆O) te dice qué hay en ese lugar, pero no cómo está construido. El plano del arquitecto (fórmula estructural) te dice cómo se conecta cada habitación, pero es plano, como el papel en que está dibujado. La maqueta a escala (modelo 3D) te deja ver la forma real y cuánto espacio ocupa cada parte, pero es más difícil de dibujar rápido en una libreta. Nadie construye un edificio solo con la dirección postal, y nadie lleva una maqueta a todas partes para dar una dirección: cada representación se usa cuando hace falta.

## D. Qué pasa realmente (nivel submicroscópico)

No existen literalmente "varillas" entre los átomos: lo que llamamos enlace covalente es una región donde dos átomos comparten densidad electrónica, manteniéndolos unidos por atracción eléctrica. Los átomos tampoco son esferas de un color fijo con un borde nítido: sus nubes electrónicas no tienen un límite exacto (el "tamaño" de un átomo es, en la práctica, una convención de a qué distancia se considera que termina su influencia). Además, una molécula real vibra constantemente: los ángulos y distancias de enlace que se muestran en los modelos son promedios, no valores congelados.

::: interactivo mol-viewer {molecula: "etanol", estilos: ["stick","sphere"], medir: true}
:::

## E. Lo que estos dibujos te hacen creer

- **Bolas y varillas** sugiere que hay espacio vacío entre átomos enlazados. El modelo de **espacio-lleno** corrige esa impresión, mostrando que los átomos "se tocan" en el sentido de que sus nubes electrónicas se solapan.
- **Espacio-lleno**, a su vez, oculta dónde están exactamente los enlaces — para eso conviene volver a bolas y varillas.
- **La fórmula esqueleto** puede hacer pensar, a quien recién la ve, que esa molécula "no tiene hidrógenos". En realidad los omite por convención, no porque no existan.
- **Un dibujo plano en el papel** puede sugerir que la molécula es plana. El visor 3D corrige esto: el etanol tiene una geometría tridimensional, con ángulos de enlace cercanos a 109,5° alrededor de cada carbono (geometría tetraédrica).
- **Los colores CPK** (oxígeno rojo, carbono gris, hidrógeno blanco) son 🟦 una convención acordada por la comunidad, no una propiedad real de los átomos — ver Unidad 1.

## F. Compara: ninguna es "la verdadera"

Aquí es donde se ve con más claridad por qué ninguna representación es suficiente por sí sola. El **dimetil éter** tiene exactamente la misma fórmula molecular que el etanol (C₂H₆O), pero es un gas a temperatura ambiente con propiedades químicas muy distintas al etanol, que es un líquido. La fórmula molecular por sí sola no puede distinguirlos: hace falta la fórmula estructural (o el modelo 3D) para ver que los átomos están conectados de forma diferente.

::: interactivo mol-viewer {molecula: "dimetileter", estilos: ["stick","sphere"], comparar_con: "etanol"}
:::

## G. Para quien quiera ir más allá

A esta posibilidad de que dos moléculas compartan fórmula molecular pero tengan estructuras (y propiedades) distintas se le llama **isomería**, y es la prueba más directa de que la fórmula molecular es, por diseño, una representación incompleta: nunca pretendió mostrar conectividad. En moléculas más complejas existen también los llamados isómeros conformacionales (formas que una misma molécula adopta al rotar sus enlaces simples), que se describen con herramientas adicionales como las proyecciones de Newman.

## H. Actividad

::: actividad
1. Etanol y dimetil éter comparten fórmula molecular. ¿Qué representación hace falta para distinguirlos, y por qué la fórmula molecular no alcanza?
2. Explica con tus palabras qué información pierdes al pasar de un modelo de bolas y varillas a uno de espacio-lleno, y qué información ganas.
3. Dibuja (en papel) la fórmula esqueleto de una molécula sencilla que elijas y luego indica cuántos hidrógenos "invisibles" tiene cada vértice.
:::
