---
unidad: 0
titulo: Introducción — el abismo perceptual
molecula_central: agua
niveles: [macro, submicro, simbolico]
---

## A. Lo que vemos

Un vaso de agua hirviendo. Un huevo que, al cocinarse, pasa de líquido transparente a sólido blanco. Un clavo de hierro que, con los días, se cubre de una capa naranja. Estas son las tres escenas a las que volveremos una y otra vez en esta aplicación: **agua**, **huevo** y **clavo oxidado**.

Ninguna de las tres se entiende mirándola. Puedes ver el vapor salir del agua, pero no puedes ver por qué sale a 100 °C y no antes. Puedes ver la clara del huevo volverse blanca, pero no puedes ver qué le pasó a las proteínas que contiene. Puedes ver el óxido, pero no puedes ver los electrones que el hierro perdió para formarlo.

::: interactivo scale-slider {desde: "persona", hasta: "nucleo-atomico"}
:::

## B. La representación

Entre lo que observamos y lo que ocurre hay una diferencia de tamaño casi imposible de imaginar. El ojo humano, sin ayuda, distingue como mucho detalles de un décimo de milímetro (10⁻⁴ m, orden de magnitud). Una molécula de agua mide alrededor de 0,3 nanómetros (3×10⁻¹⁰ m). La diferencia entre ambos números es de un factor cercano a un millón.

🟨 *Simplificación deliberada: los "0,1 mm" y "0,3 nm" que acabamos de usar son órdenes de magnitud aproximados, no medidas exactas de un objeto o de un ojo en particular. Sirven para dar una idea de escala, no un dato clínico u óptico preciso.*

Para cruzar esa distancia, la química no usa fotografías: usa **representaciones**. Un símbolo atómico, una fórmula, un diagrama de flechas, un modelo de bolas y varillas no son la realidad química; son herramientas construidas para hacer visible *un aspecto* de esa realidad, del mismo modo que un termómetro no es el calor, pero permite razonar sobre él.

## C. Una metáfora para pensarlo

Imagina que quieres describir una ciudad a alguien que nunca la visitó. Un mapa de carreteras te sirve para llegar en coche; un mapa topográfico te sirve para saber dónde hay pendiente; una foto satelital te sirve para ver la forma de los tejados. Ningún mapa es "la ciudad verdadera" y ningún mapa es prescindible: cada uno responde a una pregunta distinta.

La química funciona igual. Cuando alguien te muestra la fórmula H₂O, no te está mostrando cómo se ve una molécula de agua: te está dando la respuesta a una pregunta concreta ("¿de qué está hecha?"). Cuando te muestra un modelo de bolas y varillas, responde otra pregunta ("¿qué forma tiene?"). El error más común en el aprendizaje de la química —y el tema central de esta aplicación— es tratar una de estas respuestas como si fuera la pregunta completa.

*Límite de la metáfora: los mapas se dibujan mirando el territorio desde arriba. Los modelos químicos se construyen sin poder mirar directamente el átomo o la molécula; se deducen a partir de experimentos indirectos (espectros, difracción de rayos X, comportamiento químico). Volveremos sobre esto en la Unidad 1.*

## D. Qué pasa realmente (nivel submicroscópico)

Cuando el agua hierve, no "desaparece": sus moléculas, que estaban muy cerca unas de otras y se sujetaban mediante puentes de hidrógeno (atracciones eléctricas débiles entre el oxígeno de una molécula y un hidrógeno de otra), ganan suficiente energía de movimiento para romper esas atracciones y separarse, pasando a ocupar mucho más espacio como gas. Nada de esto es visible: lo que vemos —el burbujeo, el vapor— es la consecuencia macroscópica de billones de eventos submicroscópicos simultáneos.

## E. Lo que la falta de una imagen te hace creer

Cuando no existe una representación explícita para algo, la mente tiende a rellenar el hueco con la intuición cotidiana, y esa intuición casi siempre falla en la escala atómica. Algunos ejemplos que reaparecerán en los capítulos siguientes:

- Pensar que, si algo es invisible, "no hay nada ahí" en vez de "hay algo demasiado pequeño para verse".
- Suponer que las propiedades de un material (color, brillo, dureza) pertenecen también a sus átomos individuales.
- Imaginar que una reacción química ocurre de golpe y de forma ordenada, cuando en realidad es el resultado estadístico de enormes cantidades de colisiones, la mayoría de ellas sin efecto.

## F. Compara: el triángulo de Johnstone

El químico y educador escocés Alex H. Johnstone propuso que gran parte de la dificultad de aprender química no viene de que la química sea "difícil" en sí misma, sino de que se enseña a la vez en tres niveles distintos, y rara vez se distingue con claridad en cuál se está trabajando en cada momento:

::: interactivo johnstone-triangle {ejemplo: "agua"}
:::

| Nivel | Qué es | Ejemplo con el agua |
|---|---|---|
| **Macroscópico** | Lo que se observa o se mide directamente | Un vaso de agua hirviendo a 100 °C al nivel del mar |
| **Submicroscópico** | Partículas y sus interacciones, invisibles | Moléculas de H₂O rompiendo puentes de hidrógeno y separándose |
| **Simbólico** | Símbolos, fórmulas, ecuaciones, diagramas, modelos | H₂O(l) → H₂O(g) |

🟦 *Convención: el "triángulo" en sí —dibujar estos tres niveles como vértices de un triángulo— es una convención didáctica que ha adoptado buena parte de la investigación en educación química para representar la idea de Johnstone; el propio Johnstone la formuló en 1982 y 1991 como tres niveles de pensamiento, no necesariamente como un diagrama triangular.*

A lo largo de esta aplicación usarás un pequeño indicador con estos tres colores para saber en qué nivel estás parado en cada momento.

## G. Para quien quiera ir más allá

Johnstone no solo describió los tres niveles: propuso que el aprendizaje se atasca cuando se le pide a un estudiante que use el nivel simbólico (ecuaciones, fórmulas) sin haber construido antes un modelo mental razonable del nivel submicroscópico. Es como pedirle a alguien que lea una partitura sin haber escuchado nunca música: puede aprender las reglas de memoria, pero no "oye" lo que representa. Investigaciones posteriores (Talanquer, 2011; Taber, 2013 — ver bibliografía) han matizado y discutido esta idea, por ejemplo señalando que los tres niveles no siempre están tan separados como sugiere el diagrama, o que existe un cuarto nivel "humano/afectivo" relevante para cómo aprendemos.

## H. Actividad

::: actividad
1. Clasifica cada frase según el nivel de Johnstone (macro / submicro / simbólico): "El clavo se puso naranja", "Fe → Fe³⁺ + 3e⁻", "Los átomos de hierro perdieron electrones que fueron capturados por el oxígeno del aire".
2. ¿Por qué decimos que una fórmula química "no es una foto"? Explica con tus propias palabras usando la metáfora del mapa.
3. Elige un fenómeno cotidiano distinto a los tres ejemplos de esta unidad y describe qué dirías en el nivel macro y qué crees que ocurre en el nivel submicroscópico.
:::
