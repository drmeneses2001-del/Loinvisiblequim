---
unidad: 6
titulo: Tabla comparativa de sistemas de representación
---

## Por qué esta tabla

Cada capítulo anterior mostró, para un caso concreto, que ninguna representación es "la verdadera": cada una muestra un aspecto y oculta otros. Esta tabla reúne todas las representaciones usadas en la aplicación en un solo lugar, para que puedas compararlas directamente y elegir la adecuada según la pregunta que quieras responder.

::: interactivo comparison-table {fuente: "content/data/comparison-table.json"}
:::

La tabla es filtrable por unidad, por nivel de Johnstone y por tipo de marcador (convención / simplificación / supuesto). El objetivo no es memorizarla, sino usarla como referencia cuando dudes "¿qué representación necesito para esta pregunta?".
