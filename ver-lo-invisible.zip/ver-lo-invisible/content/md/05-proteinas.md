---
unidad: 5
titulo: Plegamiento de proteínas
molecula_central: proteina-esquematica
niveles: [macro, submicro, simbolico]
---

## A. Lo que vemos

La clara de un huevo es líquida y transparente. Al calentarla, se vuelve blanca, opaca y sólida — y no vuelve a ser transparente aunque se enfríe de nuevo. El cabello, húmedo y liso, se riza de forma distinta si se le aplica calor o ciertos productos. En ambos casos, lo que cambia es la forma de proteínas, no su composición química elemental.

⚠️ *Nota técnica de esta versión de la app: los modelos 3D de esta unidad son coordenadas reales del Protein Data Bank — la ubiquitina (entrada 1UBQ) y la hemoglobina (entrada 2HHB) — no estructuras generadas artificialmente. La única simplificación deliberada es que se retiraron las moléculas de agua cristalográficas de la hemoglobina, por claridad visual; el resto de los átomos, incluidos los grupos hemo, son los depositados originalmente.*

## B. La representación

Una proteína se puede representar en al menos cuatro niveles de detalle, cada uno renunciando a más información que el anterior a cambio de ganar claridad:

1. **Secuencia de una letra (1D):** una cadena de letras como `MQIFVKTLTG…`, donde cada letra es un aminoácido. 🟦 convención.
2. **Todos los átomos:** un modelo de bolas y varillas de cada átomo. A partir de unos pocos cientos de aminoácidos, esto se vuelve visualmente ilegible.
3. **Esqueleto (solo carbonos α):** una línea que conecta únicamente el "carbono central" de cada aminoácido, mostrando la forma general de la cadena.
4. **Diagrama de listones (ribbon/cartoon):** las hélices se dibujan como espirales y las láminas como flechas planas. 🟦 convención introducida por la bioquímica e ilustradora científica Jane S. Richardson (1981).

::: interactivo protein-layers {capas: ["atomos","esqueleto","listones"]}
:::

## C. Una metáfora para pensarlo

El diagrama de listones es como el mapa del metro de una ciudad. Un mapa de metro no respeta las distancias reales, ni dibuja las calles, ni la forma exacta de las curvas: solo muestra qué estación conecta con cuál, y de qué línea es cada tramo. Nadie camina por la ciudad guiándose por el mapa del metro, pero es exactamente la herramienta correcta para entender la topología del sistema. El diagrama de listones hace lo mismo con una proteína: renuncia a mostrar cada átomo para que se pueda ver, de un vistazo, la arquitectura general — qué tramo es una hélice, cuál es una lámina, cómo se conectan entre sí.

## D. Qué pasa realmente (nivel submicroscópico)

Una proteína es, antes de plegarse, una cadena larga de aminoácidos unidos en un orden específico (la secuencia, determinada genéticamente). Esa cadena, guiada principalmente por interacciones débiles —puentes de hidrógeno entre partes de la propia cadena, y el llamado efecto hidrofóbico, que empuja a las porciones que rechazan el agua hacia el interior de la proteína—, se dobla sobre sí misma en microsegundos o segundos hasta alcanzar una forma tridimensional estable. Esa forma final es lo que determina qué función cumple la proteína: una enzima, una proteína estructural, un transportador.

En el caso de la ubiquitina que estás viendo (76 aminoácidos), aproximadamente el 87 % de la cadena participa en algún tipo de estructura secundaria estabilizada por puentes de hidrógeno: tres vueltas y media de hélice α, un tramo corto de hélice 3₁₀, y una lámina β mixta de cinco hebras — datos tomados de la propia entrada 1UBQ del RCSB PDB (ver bibliografía).

Calentar una proteína (como al cocinar un huevo) puede romper esas interacciones débiles sin romper los enlaces fuertes que unen a los aminoácidos entre sí en la cadena: la proteína pierde su forma (se desnaturaliza) pero no se descompone en sus piezas.

## E. Lo que estos dibujos te hacen creer

- **El diagrama de listones** puede sugerir que la proteína es una cinta hueca, o que su interior está vacío. En realidad, el interior está densamente ocupado por cadenas laterales de aminoácidos que el diagrama simplemente no dibuja.
- **La secuencia de una letra** puede hacer pensar que la proteína "es" una cadena lineal, sin más. La secuencia es solo el punto de partida: la función depende de la forma tridimensional final, no de la secuencia por sí sola.
- **Los modelos estáticos** (de cualquier tipo) pueden sugerir que una proteína es rígida, como una estatua. En realidad las proteínas son estructuras dinámicas que vibran y, en muchos casos, cambian de forma parcialmente para cumplir su función (por ejemplo, al unirse a otra molécula).
- **Colorear por tipo de estructura secundaria** (hélices de un color, láminas de otro) puede sugerir que "las hélices son de ese color" de forma intrínseca — es, igual que los colores CPK de la Unidad 2, una convención de visualización, no una propiedad química de esa parte de la cadena.

## F. Compara: ninguna es "la verdadera"

::: interactivo protein-layers {capas: ["atomos","esqueleto","listones","cuaternaria"], contador_atomos: true}
:::

Activa el contador de átomos al cambiar de capa: verás cuántos átomos se están dibujando realmente en cada modo y cuántos se omiten. Esa comparación numérica es la forma más directa de entender qué se gana (claridad) y qué se pierde (detalle atómico) en cada nivel de simplificación.

## G. Para quien quiera ir más allá

Un experimento clásico de Christian Anfinsen (1973) mostró que, en muchos casos, una proteína desplegada en el laboratorio puede volver a plegarse por sí sola hasta su forma funcional original, lo que sugiere que la secuencia de aminoácidos contiene, en sí misma, toda la información necesaria para el plegamiento (sin necesidad de una "plantilla" externa). Predecir esa forma final a partir solo de la secuencia fue, durante décadas, uno de los grandes problemas abiertos de la bioquímica; sistemas computacionales como AlphaFold (Jumper et al., 2021) han logrado avances notables en esa predicción, aunque con límites que siguen siendo objeto de investigación activa (por ejemplo, en proteínas con múltiples conformaciones posibles o que dependen de otras moléculas para plegarse correctamente).

La hemoglobina que ves en la capa "Subunidades" es la estructura depositada en 1984 por Gerald Fermi y Max Perutz —quien había recibido el Premio Nobel de Química en 1962 precisamente por descifrar la estructura de esta proteína— junto con Boaz Shaanan y Robert Fourme (entrada 2HHB del RCSB PDB; ver bibliografía). Cada una de sus cuatro subunidades cambia ligeramente de forma según lleve oxígeno o no, y ese cambio coordinado entre las cuatro es lo que le permite a la hemoglobina captar oxígeno eficientemente en los pulmones y soltarlo donde el cuerpo lo necesita — un ejemplo de que, en las proteínas, la forma tridimensional completa (no la secuencia por sí sola) es lo que hace posible la función.

## H. Actividad

::: actividad
1. ¿Por qué cocinar un huevo es un cambio permanente, si en teoría "solo" se rompen interacciones débiles?
2. Explica, con la metáfora del mapa del metro, qué información pierde deliberadamente un diagrama de listones y por qué esa pérdida es útil.
3. ¿Qué diferencia hay entre la estructura primaria y la estructura terciaria de una proteína? Da un ejemplo de cada una usando esta unidad.
:::
