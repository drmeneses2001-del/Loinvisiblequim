---
unidad: 7
titulo: Bibliografía y glosario
---

## Cómo leer esta bibliografía

Las referencias están separadas en dos grupos: **(A) fuentes primarias de investigación en educación química, historia y filosofía de la química**, que sustentan las afirmaciones pedagógicas y epistemológicas de esta app; y **(B) fuentes de química general y estructural**, que sustentan los datos numéricos (longitudes de enlace, escalas atómicas, etc.).

Cada referencia incluye un estado de verificación:

- ✅ **Verificado** — datos confirmados contra al menos una fuente secundaria confiable (base de datos bibliográfica o la propia editorial) en la fecha de desarrollo de esta app.
- ⚠️ **Verificación parcial** — la referencia existe y es correcta en lo esencial, pero algún dato específico (edición, páginas exactas) no pudo confirmarse de forma independiente y debe revisarse antes de publicar.
- 🔎 **Pendiente** — eje de búsqueda identificado, sin una cita concreta todavía asignada.

::: interactivo bibliography-table {fuente: "content/data/bibliography.json"}
:::

## Nota de honestidad metodológica

Esta bibliografía se elaboró combinando el conocimiento del desarrollador con verificación activa mediante búsqueda en fuentes académicas (Wiley, ACS Publications, ERIC, Semantic Scholar, entre otras) en la fecha de desarrollo. Las referencias marcadas ✅ fueron confirmadas de ese modo. Las marcadas ⚠️ o 🔎 se mantienen visibles deliberadamente, en vez de completarse con datos inventados, siguiendo el principio rector de esta app: es preferible mostrar una incertidumbre reconocida que una precisión falsa.
