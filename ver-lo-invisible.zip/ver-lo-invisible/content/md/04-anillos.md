---
unidad: 4
titulo: Anillos y aromaticidad
molecula_central: benceno
molecula_contraste: ciclohexano
niveles: [macro, submicro, simbolico]
---

## A. Lo que vemos

El benceno es un líquido de olor característico (y tóxico — no debe manipularse sin las precauciones adecuadas de un laboratorio). Es la molécula que dio origen, hace más de 150 años, a uno de los problemas de representación más discutidos de la química orgánica: ¿cómo se dibuja algo que no se comporta como ninguna otra molécula conocida en su momento?

## B. La representación

El benceno (C₆H₆) tiene cuatro representaciones habituales:

1. **Estructuras de Kekulé:** dos hexágonos con enlaces simples y dobles alternados, que se dibujan como si fueran intercambiables entre sí. 🟨 simplificación.
2. **Círculo inscrito en el hexágono:** 🟦 convención que reconoce que ningún enlace simple ni doble describe bien la situación real.
3. **Estructuras de resonancia con flecha de doble punta (↔):** 🟦 convención — esta flecha **no** significa "equilibrio" ni "cambia con el tiempo entre A y B"; significa que la molécula real es un promedio de ambas descripciones.
4. **Modelo 3D:** un hexágono plano y perfectamente regular, con los seis enlaces carbono-carbono de la misma longitud.

::: interactivo ring-toggle {molecula: "benceno"}
:::

## C. Una metáfora para pensarlo

Imagina un retrato robot elaborado a partir de dos testigos de un mismo rostro, ninguno de los cuales lo vio completo. Cada estructura de Kekulé es la descripción de un testigo: razonable, pero incompleta. El rostro real —la molécula real de benceno— no "alterna" entre las dos descripciones ni se parece exactamente a ninguna de ellas por separado: es un tercer objeto, distinto de ambos testimonios, que el círculo intenta reconocer sin fingir precisión que no tiene.

## D. Qué pasa realmente (nivel submicroscópico)

En el benceno, seis electrones (uno de cada átomo de carbono, procedente de un orbital p) no pertenecen a un enlace en particular: forman una nube compartida por igual encima y debajo del plano del anillo, distribuida entre los seis carbonos. Esto se llama deslocalización electrónica. Como consecuencia, las seis distancias carbono-carbono del anillo son idénticas entre sí:

::: interactivo mol-viewer {molecula: "benceno", medir: true, resaltar: "distancias-CC"}
:::

En un modelo generado con los mismos parámetros usados en visores moleculares reales, las seis distancias C–C del benceno salen iguales entre sí (aproximadamente 1,39–1,40 Å según la fuente experimental consultada — ver bibliografía general), un valor intermedio entre un enlace simple C–C típico (~1,54 Å) y uno doble C=C típico (~1,34 Å). Ningún enlace simple ni doble aislado tiene esa longitud: es la deslocalización la que la produce.

## E. Lo que estos dibujos te hacen creer

- **Las estructuras de Kekulé** sugieren que el benceno "alterna rápidamente" entre dos moléculas distintas. No hay tal alternancia: solo hay una molécula, con una única estructura electrónica que ningún dibujo de enlaces simples y dobles captura por sí solo.
- **El círculo** puede sugerir, a quien lo ve por primera vez, que "hay un enlace circular" o que "no hay electrones π" (electrones de doble enlace). Al contrario: el círculo representa precisamente la presencia de esos seis electrones, deslocalizados.
- **La flecha de resonancia (↔)** se confunde fácilmente con una flecha de equilibrio químico (⇌), que sí implica que dos especies distintas coexisten y se interconvierten. La resonancia no es eso: no hay dos moléculas reales que se interconviertan, hay una sola molécula que ningún dibujo aislado describe del todo.
- **Ver el hexágono dibujado plano en el papel** puede hacer pensar que todos los anillos de seis carbonos son planos. El ciclohexano (sin el sistema de electrones deslocalizados del benceno) no es plano: adopta una forma tridimensional llamada "de silla", que puedes comparar directamente con el benceno en el visor.

## F. Compara: ninguna es "la verdadera"

::: interactivo mol-viewer {molecula: "ciclohexano", comparar_con: "benceno", nota: "el benceno es plano; el ciclohexano no"}
:::

## G. Para quien quiera ir más allá

Existe un criterio formal, la regla de Hückel (4n+2 electrones π en un sistema cíclico plano y conjugado, con n entero), que permite predecir si un anillo será aromático. El benceno cumple esta regla con n=1 (6 electrones π). Otros anillos aromáticos aparecen en moléculas cotidianas: el naftaleno (dos anillos fusionados), las bases nitrogenadas del ADN, o la vainillina (responsable del aroma de la vainilla). La conocida anécdota de que Kekulé imaginó la estructura circular del benceno tras soñar con una serpiente mordiéndose la cola es una historia repetida en muchos libros de texto, pero su historicidad exacta ha sido cuestionada por historiadores de la ciencia (ver, por ejemplo, la discusión de Alan J. Rocke sobre las fuentes primarias); se cuenta aquí como anécdota, no como hecho histórico confirmado.

## H. Actividad

::: actividad
1. Explica por qué la flecha de resonancia (↔) no debe leerse como un equilibrio químico.
2. Si tuvieras que medir las seis distancias carbono-carbono del benceno sin saber nada de su estructura, ¿qué esperarías encontrar si el enlace realmente alternara entre simple y doble como en Kekulé? ¿Coincide con lo que realmente se mide?
3. ¿Por qué el círculo es, en cierto sentido, "más honesto" que cualquiera de las dos estructuras de Kekulé por separado, aunque sea menos preciso en los detalles?
:::
