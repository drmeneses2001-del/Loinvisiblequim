# Ver lo Invisible — por qué la química piensa en representaciones

Aplicación web interactiva + PDF integral + capítulos Markdown, construida a partir
del documento de arquitectura aprobado. Este README documenta cómo correrla,
qué decisiones se tomaron por defecto (sección 8 del documento de arquitectura)
y qué limitaciones reales tiene esta primera versión.

## Cómo correr la app

Los datos (moléculas, proteínas, JSON de contenido) se cargan con `fetch()`,
así que **no se puede abrir `index.html` con doble clic** (los navegadores
bloquean `fetch` sobre `file://` por CORS). Hay que servirla desde un
servidor estático local, por ejemplo:

```bash
cd ver-lo-invisible
python3 -m http.server 8080
# abrir http://localhost:8080/index.html
```

o con Node: `npx serve .` En un iPad en la misma red, se puede abrir
`http://<ip-de-tu-computadora>:8080/index.html` desde Safari.

## Cómo regenerar el PDF

```bash
pip install weasyprint --break-system-packages
python3 build/build_pdf.py
```

Genera `dist/ver-lo-invisible.pdf` (21 páginas con esta versión del contenido)
y copia los `.md` a `dist/md/` (entregable 3). **Los `.md` en `content/md/`
son la única fuente de verdad**: para corregir contenido se edita el `.md`
correspondiente y se vuelve a correr `md-to-json.js` (app) y `build_pdf.py` (PDF).

```bash
node build/md-to-json.js   # regenera content/json/*.json para la app
```

## Decisiones tomadas por defecto (sección 8 del documento de arquitectura)

Como no hubo respuesta explícita a esas siete preguntas, se avanzó con las
opciones propuestas allí mismo, para no bloquear el desarrollo. **Revísalas**:

1. **Reacción para flechas curvas:** ácido-base genérico (HA + :B → A⁻ + HB⁺) en el cuerpo principal; la sustitución SN2 quedó mencionada solo en el texto, no implementada como segunda animación.
2. **Proteína cuaternaria:** no se usó hemoglobina real — ver limitación de proteínas más abajo.
3. **Motor de PDF:** WeasyPrint (HTML/CSS). Funciona bien y es fácil de mantener.
4. **Idioma:** solo español.
5. **Alcance de la nube orbital:** solo hidrógeno (1s, 2pz, 3dz²), calculado analíticamente. No se generaron orbitales de átomos multielectrónicos.
6. **Persistencia:** no implementada todavía (ni siquiera `localStorage`). La app no guarda progreso entre sesiones en esta versión.
7. **Licencia:** no definida. Falta decidir y añadir un archivo `LICENSE`.

## Limitaciones honestas de esta versión (léelas antes de publicar)

### Proteínas: estructuras sintéticas, no reales
El entorno de desarrollo no tuvo acceso de red a `rcsb.org`, así que
`content/data/proteins/*.pdb` son estructuras **generadas proceduralmente**
(hélice α y lámina β ideales, con los parámetros geométricos de Pauling,
Corey y Branson, 1951), no las coordenadas reales de la ubiquitina (1UBQ)
ni de la hemoglobina (2HHB/1A3N) que recomendaba la arquitectura original.
Esto está declarado explícitamente en `05-proteinas.md` y en la interfaz
(aviso ⚠️ visible en el visor de proteínas). **Antes de publicar la app**,
descarga esas dos entradas reales de rcsb.org y reemplaza los `.pdb`
sintéticos (el componente `protein-layers.js` solo necesita que el archivo
tenga los campos estándar `ATOM`/ `TER`/`END`; no requiere cambios de código
si el nuevo archivo sigue el formato PDB estándar, aunque probablemente haga
falta ajustar la selección de cadenas si la proteína real tiene más átomos
por residuo).

### Moléculas: generadas con RDKit, no descargadas de PubChem
Por la misma razón de red, las moléculas pequeñas (etanol, dimetil éter,
benceno, etc.) no se descargaron de PubChem: se generaron localmente con
RDKit (SMILES + optimización de campo de fuerzas MMFF94). Las geometrías
resultantes son químicamente razonables y se verificaron contra valores de
consenso (ej.: las seis distancias C–C del benceno salieron en 1.395 Å,
consistente con el valor experimental ampliamente citado de ~1.39–1.40 Å),
pero no son, en sentido estricto, "la" estructura cristalográfica de
referencia. Antes de publicar, sería razonable contrastarlas contra PubChem.

### Bibliografía: verificada activamente, pero no al 100%
Se verificaron por búsqueda web (no de memoria) las siguientes referencias
antes de escribirlas: Johnstone (1982), Johnstone (1991), Ben-Zvi, Eylon y
Silberstein (1986), y Bhattacharyya y Bodner (2005) — estas llevan estado
"✅ verificado" en `bibliography.json` con la fuente de verificación anotada.
El resto de las ~35 referencias quedaron con estado "⚠ parcial" (existen y
son correctas en lo esencial, pero algún dato específico no se confirmó de
forma independiente) o "🔎 pendiente" (ejes de búsqueda sin cita concreta
todavía) — nunca se completaron con datos inventados. Revisa la tabla
completa en `content/data/bibliography.json` o en la Unidad 7 de la app/PDF
antes de dar la bibliografía por definitiva.

### Sin persistencia ni pruebas automatizadas
No hay `localStorage` para guardar progreso, y no se corrieron pruebas en un
iPad físico ni en Safari real (solo se verificó que los archivos se sirven
correctamente vía HTTP y que el HTML/CSS/JS pasa validación de sintaxis).
Antes de dar por buena la app, pruébala en un iPad real.

## Estructura del proyecto

Ver el documento de arquitectura (`arquitectura_ver_lo_invisible.md`, entregado
antes de esta fase) para el detalle completo. Resumen:

```
ver-lo-invisible/
├── index.html              # shell de la app
├── app/                    # JS/CSS de la aplicación (sin build step)
│   ├── main.js              # router + motor de render
│   ├── markdown-lite.js      # renderizador Markdown propio
│   └── components/          # un módulo por cada interactivo
├── content/
│   ├── md/                  # ← FUENTE ÚNICA DE VERDAD del texto
│   ├── json/                 # generado por build/md-to-json.js
│   ├── data/                 # moléculas (.sdf), proteínas (.pdb), bibliografía, tabla comparativa
├── vendor/                  # 3Dmol.js, three.js, Chart.js (vendorizados, sin CDN)
├── build/
│   ├── md-to-json.js         # compilador para la app
│   ├── build_pdf.py          # compilador para el PDF
│   └── pdf/                  # plantilla HTML + CSS de impresión
└── dist/                    # salidas: PDF final + copia de los .md
```
